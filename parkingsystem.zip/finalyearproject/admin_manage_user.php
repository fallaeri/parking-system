<!DOCTYPE html>
<html>
<head>
    <title>User Signed In</title>
</head>
<style>
       body, table {
    margin: 0;
    padding: 0;
    font-family: 'Arial', sans-serif;
    background-color: #f0f0f0; /* Optional: Set a background color for the body */
}

table {
    font-size: 20px;
    width: 80%;
    border-collapse: collapse;
    margin: 20px auto; /* Center the table */
}

th, td {
    border: 1px solid #ddd;
    padding: 12px;
    text-align: center;
}

th {
    background-color: black;
    color: white;
}

td {
    background-color: white;
    color: black;
}

#td1 {
    background-color: black;
    color: white;
    border: 10px;
    margin-top: -10px;
    padding: 10px;
    text-align: center;
}

.main-content {
    padding-top: 80px; /* Adjust this value based on the header height */
    flex: 1;
}

h1 {
    color: white;
    text-align: center; /* Center the heading */
}
</style>
<body>
<?php
include 'header.php';
?>


<div class="main-content">
    <h1>Manage Users</h1>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Username</th>
                <th>Email</th>
                <th>Car Plate</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // Database connection
            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "parkingsystem"; 

            $conn = new mysqli($servername, $username, $password, $dbname);

            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            // Fetch users
            $sql = "SELECT id, username, email, license_plate FROM users";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>
                        <td>" . $row['id'] . "</td>
                        <td>" . $row['username'] . "</td>
                        <td>" . $row['email'] . "</td>
                        <td>" . $row['license_plate'] . "</td>
                        <td>
                            <form method='POST' action='delete_user.php' style='display:inline;'>
                                <input type='hidden' name='id' value='" . $row['id'] . "'>
                                <button type='submit' style='background-color: red; color: white; border: none; padding: 5px 10px; cursor: pointer;'>Delete</button>
                            </form>
                        </td>
                    </tr>";
                }
            } else {
                echo "<tr><td colspan='4'>No users found</td></tr>";
            }
            ?>
        </tbody>
    </table>
</div>

</body>
</html>

<?php include 'footer.php'; ?>
<?php
include 'db.php';
include 'header.php';

try {
    // Establish PDO connection
    $pdo = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Fetch parking slots data (status, position) for the parking lot table
$slotsQuery = $pdo->query("SELECT slot_id, slot_name, is_available FROM parking_slots");
$slotsData = $slotsQuery->fetchAll(PDO::FETCH_ASSOC);

// Fetch bookings for pagination
$logsPerPage = 10;  // Show 10 bookings per page
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $logsPerPage;

$logsQuery = $pdo->prepare("SELECT bookings.id, bookings.booking_code, bookings.license_plate, bookings.payment_method, 
                            bookings.parking_duration, bookings.amount, bookings.booking_status, bookings.booking_date, 
                             parking_slots.slot_name 
                            FROM bookings
                            JOIN parking_slots ON bookings.slot_id = parking_slots.slot_id
                            ORDER BY bookings.booking_date DESC 
                            LIMIT :offset, :limit");
$logsQuery->bindParam(':offset', $offset, PDO::PARAM_INT);
$logsQuery->bindParam(':limit', $logsPerPage, PDO::PARAM_INT);
$logsQuery->execute();
$logs = $logsQuery->fetchAll(PDO::FETCH_ASSOC);

// Fetch total number of bookings for pagination
$totalLogsQuery = $pdo->query("SELECT COUNT(*) AS total FROM bookings");
$totalLogs = $totalLogsQuery->fetch(PDO::FETCH_ASSOC);
$totalPages = ceil($totalLogs['total'] / $logsPerPage);

// Handle report generation
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['generate_report'])) {
    $startDate = $_POST['start_date'];
    $endDate = $_POST['end_date'];

    // Validate date range
    if ($startDate > $endDate) {
        echo "<script>alert('Start date cannot be later than the end date');</script>";
    } else {
        $reportQuery = $pdo->prepare("SELECT bookings.id, bookings.booking_code, bookings.license_plate, bookings.payment_method, 
                                      bookings.parking_duration, bookings.amount, bookings.booking_status, bookings.booking_date, 
                                      parking_slots.slot_name
                                      FROM bookings
                                      JOIN parking_slots ON bookings.slot_id = parking_slots.slot_id
                                      WHERE booking_date BETWEEN :start_date AND :end_date");
        $reportQuery->execute(['start_date' => $startDate, 'end_date' => $endDate]);
        $reportData = $reportQuery->fetchAll(PDO::FETCH_ASSOC);

        if ($reportData) {
            if (ob_get_contents()) {
                ob_end_clean();
            }
            header('Content-Type: text/csv');
            header('Content-Disposition: attachment; filename="report.csv"');   
            $output = fopen('php://output', 'w');


fputcsv($output, ['ID', 'Booking Code', 'License Plate', 'Payment Method', 'Parking Duration', 'Amount', 'Booking Status', 'Booking Date', 'Slot Name']);


foreach ($reportData as &$row) {
    // Modify the booking_date field to ensure Excel interprets it correctly
    $row['booking_date'] = "'" . $row['booking_date'];
}

// Write each row to the CSV
foreach ($reportData as $row) {
    fputcsv($output, $row);
}

// Close the file
fclose($output);

            exit; // Terminate script after output
        } else {
            echo "<script>alert('No data found for the selected date range');</script>";
        }
    }
}

?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Booking</title>
    <style>
     body {
    font-family: 'Arial', sans-serif;
    margin: 0;
    padding: 0;
    color: white; /* White text for consistency */
}

.container {
    max-width: 1000px;
    margin: 0 auto;
    padding: 20px;
    background-color: rgba(0, 0, 0, 0.8); /* Semi-transparent black for contrast */
    border-radius: 10px; /* Rounded corners */
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.5); /* Deep shadow for depth */
}

.alert {
    padding: 15px;
    background-color: white; /* Amber background for alert */
    color: black; /* Black text for readability */
    margin-bottom: 20px;
    text-align: center;
    border-radius: 5px; /* Rounded corners */
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.3);
    font-weight: bold;
}

h1, h2 {
    color: white; /* Consistent with body text */
    text-align: center;
    margin-bottom: 20px;
}

h1 {
    font-size: 28px;
}

h2 {
    font-size: 22px;
}

.form-group {
    margin-bottom: 20px;
}

label {
    font-weight: bold;
    display: block;
    margin-bottom: 10px;
    color: white; /* Amber text for labels */
}

input[type="date"],
button {
    width: 100%;
    padding: 12px;
    font-size: 16px;
    border: 1px solid #555; /* Dark border for inputs */
    border-radius: 5px;
    background-color: rgba(255, 255, 255, 0.1); /* Slightly transparent white */
    color: white;
    transition: all 0.3s ease;
}

input[type="date"]:focus {
    border-color: white; /* Amber highlight on focus */
    outline: none;
    box-shadow: 0 0 8px rgba(255, 193, 7, 0.5);
}

button {
    background-color: #333333; /* Dark background for buttons */
    color: white; /* Amber text */
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-weight: bold;
    transition: background-color 0.3s ease, transform 0.2s ease;
}

button:hover {
    background-color: white; /* Amber on hover */
    color: black; /* Black text on hover */
    transform: scale(1.03);
}

table {
    width: 100%;
    border-collapse: collapse;
    margin: 25px 0;
    background-color: black; /* Black background for table */
    border-radius: 10px; /* Rounded corners */
    overflow: hidden;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3);
}

table th, table td {
    padding: 15px;
    text-align: center;
    font-size: 16px;
    border-bottom: 1px solid #444; /* Subtle border */
    color: white;
}

table th {
    background-color: #333333; /* Dark gray for header */
    color: white; /* Amber text for header */
}

table tbody tr:nth-child(even) {
    background-color: rgba(255, 255, 255, 0.1); /* Light gray for even rows */
}

table tbody tr:hover {
    background-color: rgba(255, 255, 255, 0.2); /* Slightly brighter on hover */
}

table tbody tr:last-of-type {
    border-bottom: 2px solid white; /* Amber border for last row */
}

table .available {
    color: #00FF00; /* Bright green for availability */
    font-weight: bold;
}

table .occupied {
    color: #FF0000; /* Bright red for occupied */
    font-weight: bold;
}

.pagination {
    text-align: center;
    margin: 20px 0;
}

.pagination a {
    color: black;
    background-color: white; /* Amber for links */
    padding: 10px 20px;
    text-decoration: none;
    border-radius: 5px;
    margin: 0 5px;
    transition: background-color 0.3s ease;
}

.pagination a:hover {
    background-color: #FFD54F; /* Lighter amber on hover */
    color: black;
}

.section {
    margin-bottom: 20px;
    padding: 20px;
    background-color: rgba(0, 0, 0, 0.8); /* Semi-transparent black for sections */
    border-radius: 10px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.5);
}

.main-content {
            padding-top: 80px; /* Adjust this value based on the header height */
            flex: 1; /* Allow the main content to grow */
        }


    </style>
</head>
<body>
<div class="main-content">
    <div class="container">
        <h1>Parking Lot Dashboard</h1>

        <?php if (isset($_GET['message'])): ?>
            <div class="alert"><?= htmlspecialchars($_GET['message']) ?></div>
        <?php endif; ?>

        <!-- Booking Logs -->
        <section>
            <h2>Bookings</h2>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Booking Code</th>
                        <th>License Plate</th>
                        <th>Payment Method</th>
                        <th>Parking Duration (hrs)</th>
                        <th>Amount</th>
                        <th>Status</th>
                        <th>Booking Date</th>
                        <th>Slot Name</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($logs as $log): ?>
                        <tr>
                            <td><?= htmlspecialchars($log['id']) ?></td>
                            <td><?= htmlspecialchars($log['booking_code']) ?></td>
                            <td><?= htmlspecialchars($log['license_plate']) ?></td>
                            <td><?= htmlspecialchars($log['payment_method']) ?></td>
                            <td><?= htmlspecialchars($log['parking_duration']) ?></td>
                            <td><?= htmlspecialchars($log['amount']) ?></td>
                            <td><?= htmlspecialchars($log['booking_status']) ?></td>
                            <td><?= htmlspecialchars($log['booking_date']) ?></td>
                            <td><?= htmlspecialchars($log['slot_name']) ?></td>
                            <td>
                                <form method="POST" action="delete_booking.php" style="display:inline;">
                                    <input type="hidden" name="booking_id" value="<?= htmlspecialchars($log['id']) ?>">
                                    <button type="submit" onclick="return confirm('Are you sure you want to delete this booking?');">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </section>

        <!-- Pagination -->
        <div>
            <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                <a href="?page=<?= $i ?>"> <?= $i ?></a>
            <?php endfor; ?>
        </div>

        <!-- Report Generation -->
        <section>
            <h2>Generate Report</h2>
            <form method="POST">
                <div class="form-group">
                    <label for="start_date">Start Date:</label>
                    <input type="date" name="start_date" required>
                </div>
                <div class="form-group">
                    <label for="end_date">End Date:</label>
                    <input type="date" name="end_date" required>
                </div>
                <button type="submit"
                name="generate_report">Generate Report</button>
            </form>
        </section>
    </div>
</div>
</body>
</html>

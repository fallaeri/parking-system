<?php
session_start();

// Database connection
$conn = new mysqli("localhost", "root", "", "parkingsystem");

// Check the database connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form inputs are set and not empty
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['username'], $_POST['password'])) {
        $username = trim($_POST['username']);
        $password = trim($_POST['password']);

        if (!empty($username) && !empty($password)) {
            // Prepare and execute the query securely
            $sql = "SELECT * FROM admins WHERE username = ?";
            $stmt = $conn->prepare($sql);

            if ($stmt) {
                $stmt->bind_param("s", $username);
                $stmt->execute();
                $result = $stmt->get_result();

                // Check if a matching user exists
                if ($result->num_rows > 0) {
                    $row = $result->fetch_assoc();

                    // Verify the password
                    if (password_verify($password, $row['password'])) {
                        // Store user details in the session
                        $_SESSION['username'] = $row['username'];
                        $_SESSION['email'] = $row['email'];
                        $_SESSION['adminid'] = $row['adminid'];

                        // Redirect to the admin dashboard
                        header("Location: admin_dashboard.php");
                        exit;
                    } else {
                        // Incorrect password
                        echo "<script>
                                alert('Invalid Username or Password');
                                window.location.href='admin_login.php';
                              </script>";
                    }
                } else {
                    // Username not found
                    echo "<script>
                            alert('Invalid Username or Password');
                            window.location.href='admin_login.php';
                          </script>";
                }

                $stmt->close();
            } else {
                // Query preparation error
                die("Query preparation failed: " . $conn->error);
            }
        } else {
            // Missing username or password
            echo "<script>
                    alert('Please enter both Username and Password');
                    window.location.href='admin_login.php';
                  </script>";
        }
    } else {
        // Missing POST parameters
        echo "<script>
                alert('Please enter both Username and Password');
                window.location.href='admin_login.php';
              </script>";
    }
}

$conn->close();
?>

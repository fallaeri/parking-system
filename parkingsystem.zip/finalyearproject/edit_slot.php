<?php
include 'db.php'; // Include database connection file

// Fetch all parking slots from the database
$query = "SELECT slot_id, slot_name, position_x, position_y, is_available FROM parking_slots";
$slots = $pdo->query($query)->fetchAll(PDO::FETCH_ASSOC);

// If form is submitted for editing a parking slot
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve form data
    $slot_id = $_POST['slot_id'];
    $slot_name = $_POST['slot_name'];
    $position_x = $_POST['position_x'];
    $position_y = $_POST['position_y'];
    $is_available = isset($_POST['is_available']) ? 1 : 0;

    // Update the parking slot in the database
    $updateQuery = "UPDATE parking_slots
                    SET slot_name = :slot_name, 
                        position_x = :position_x, 
                        position_y = :position_y, 
                        is_available = :is_available
                    WHERE slot_id = :slot_id";

    $stmt = $pdo->prepare($updateQuery);
    $stmt->execute([
        'slot_name' => $slot_name,
        'position_x' => $position_x,
        'position_y' => $position_y,
        'is_available' => $is_available,
        'slot_id' => $slot_id
    ]);

    echo "Parking slot updated successfully!";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Parking Slot</title>
    <style>
        #parking-map {
            width: 800px;
            height: 1100px;
            border: 1px solid #000;
            position: relative;
        }
        .slot {
            width: 50px;
            height: 50px;
            position: absolute;
            text-align: center;
            line-height: 50px;
            cursor: pointer;
            border: 1px solid #000;
        }
        .available {
            background-color: #90ee90; /* Light green */
        }
        .occupied {
            background-color: #ffcccb; /* Light red */
        }
    </style>
</head>
<body>
    <h1>Admin - Edit Parking Slot</h1>
    
    <!-- Display Parking Slots on Map -->
    <h2>Click on a parking slot to edit</h2>
    <div id="parking-map">
        <?php foreach ($slots as $slot): ?>
            <div class="slot <?php echo $slot['is_available'] ? 'available' : 'occupied'; ?>"
                 style="top: <?php echo $slot['position_y']; ?>px; left: <?php echo $slot['position_x']; ?>px;"
                 onclick="editSlot(<?php echo $slot['slot_id']; ?>)">
                <?php echo htmlspecialchars($slot['slot_name']); ?>
            </div>
        <?php endforeach; ?>
    </div>

    <h2>Edit Parking Slot Details</h2>

    <?php
    // If a slot is selected, fetch its details for editing
    if (isset($_GET['slot_id'])) {
        $slot_id = $_GET['slot_id'];

        // Fetch the details of the selected parking slot
        $query = "SELECT slot_id, slot_name, position_x, position_y, is_available FROM parking_slots WHERE slot_id = :slot_id";
        $stmt = $pdo->prepare($query);
        $stmt->execute(['slot_id' => $slot_id]);
        $slot = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($slot) {
            // Show the form with the current slot values for editing
    ?>

    <form method="POST" action="">
        <input type="hidden" name="slot_id" value="<?php echo $slot['slot_id']; ?>">

        <label for="slot_name">Slot Name:</label>
        <input type="text" name="slot_name" id="slot_name" value="<?php echo htmlspecialchars($slot['slot_name']); ?>" required>
        <br><br>

        <label for="position_x">Position X:</label>
        <input type="number" name="position_x" id="position_x" value="<?php echo htmlspecialchars($slot['position_x']); ?>" required>
        <br><br>

        <label for="position_y">Position Y:</label>
        <input type="number" name="position_y" id="position_y" value="<?php echo htmlspecialchars($slot['position_y']); ?>" required>
        <br><br>

        <label for="is_available">Available:</label>
        <input type="checkbox" name="is_available" id="is_available" <?php echo $slot['is_available'] ? 'checked' : ''; ?>>
        <br><br>

        <button type="submit">Update Slot</button>
    </form>

    <?php
        } else {
            echo "Slot not found.";
        }
    }
    ?>

    <script>
        function editSlot(slotId) {
            // Redirect to the same page but with the slot_id as a GET parameter
            window.location.href = "edit_slot.php?slot_id=" + slotId;
        }
    </script>

</body>
</html>

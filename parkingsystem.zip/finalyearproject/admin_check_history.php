<?php
include 'header.php';
include 'footer.php';



// Database connection details
$host = "localhost";
$dbname = "parkingsystem";
$user = "root";
$password = "";

// Establish PDO connection
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $user, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Pagination logic for vehicle logs
$logsPerPage = 10;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$logOffset = ($page - 1) * $logsPerPage;

// Fetch vehicle log data with parking slot info (JOIN)
$logsQuery = $pdo->prepare("
    SELECT 
        b.id, 
        b.license_plate, 
        b.booking_date AS entry_time, 
        b.exit_time, 
        ps.slot_name, 
        ps.is_available 
    FROM 
        bookings b
    LEFT JOIN 
        parking_slots ps 
    ON 
        b.slot_id = ps.slot_id
    ORDER BY 
        b.booking_date DESC 
    LIMIT 
        :logOffset, :logsPerPage
");
$logsQuery->bindValue(':logOffset', $logOffset, PDO::PARAM_INT);
$logsQuery->bindValue(':logsPerPage', $logsPerPage, PDO::PARAM_INT);
$logsQuery->execute();
$logs = $logsQuery->fetchAll(PDO::FETCH_ASSOC);

// Count total number of logs
$totalLogsQuery = $pdo->query("SELECT COUNT(*) AS total FROM bookings");
$totalLogs = $totalLogsQuery->fetch(PDO::FETCH_ASSOC);
$totalLogsCount = $totalLogs['total'];

// Calculate total number of pages
$totalPages = ceil($totalLogsCount / $logsPerPage);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vehicle Parking History</title>
    <style>
  body {
    font-family: 'Arial', sans-serif;
    margin: 0;
    padding: 0;
    color: white; /* White text for consistency with header */
}

.container {
    max-width: 1000px;
    margin: 0 auto;
    padding: 20px;
    background-color: rgba(0, 0, 0, 0.8); /* Semi-transparent black for contrast */
    border-radius: 10px; /* Rounded corners */
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.5);
}

h1, h2 {
    color: white; /* Amber color to match hover in header */
    text-align: center;
}

.styled-table {
    width: 100%;
    border-collapse: collapse;
    margin: 25px 0;
    font-size: 1em;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3);
    border-radius: 8px;
    overflow: hidden;
    background-color: black; /* Black background for the table */
}

.styled-table thead tr {
    background-color:rgb(57, 49, 49); /* Amber for header row */
    color: black; /* Black text for header */
    text-align: left;
}
th{
    color:white;
}

.styled-table th, .styled-table td {
    padding: 15px 20px;
    border-bottom: 1px solid #444; /* Subtle border between rows */
}

.styled-table tbody tr {
    transition: background-color 0.3s;
}

.styled-table tbody tr:nth-of-type(even) {
    background-color: rgba(255, 255, 255, 0.1); /* Light gray for even rows */
}

.styled-table tbody tr:hover {
    background-color: rgba(255, 255, 255, 0.2); /* Slightly brighter gray on hover */
}

.styled-table tbody tr:last-of-type {
    border-bottom: 2px solid #333333; /* Amber border for the last row */
}

.styled-table .available {
    color: #00FF00; /* Bright green for available slots */
    font-weight: bold;
}

.styled-table .occupied {
    color: #FF0000; /* Bright red for occupied slots */
    font-weight: bold;
}

.pagination {
    text-align: center;
    margin: 20px 0;
}

.pagination a {
    color: black;
    background-color:rgb(255, 251, 251); /* Amber for links */
    padding: 10px 20px;
    text-decoration: none;
    border-radius: 5px;
    margin: 0 5px;
    transition: background-color 0.3s;
}

.pagination a:hover {
    background-color: #FFC107; /* Lighter amber on hover */
}

.main-content {
            padding-top: 80px; /* Adjust this value based on the header height */
            flex: 1; /* Allow the main content to grow */
        }

</style>

    </style>
</head>
<body>
<div style="margin-bottom:-10%;padding:1px 16px;height:1000px;">
<div class="main-content">
    <div class="container">
        <h1>Vehicle Parking History</h1>

        <!-- Vehicle Log Table with Parking Slot Info and Exit Time -->
        <section class="table-container">
            <h2>Parking History</h2>
            <table class="styled-table">
                <thead>
                    <tr>
                        <th>License Plate</th>
                        <th>Booking Date (Entry Time)</th>
                        <th>Exit Time</th>
                        <th>Parking Slot</th>
                        <th>Availability</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($logs as $log): ?>
                        <tr>
                            <td><?= htmlspecialchars($log['license_plate']) ?></td>
                            <td><?= htmlspecialchars($log['entry_time']) ?></td>
                            <td><?= htmlspecialchars($log['exit_time'] ?? 'N/A') ?></td>
                            <td><?= htmlspecialchars($log['slot_name'] ?? 'N/A') ?></td>
                            <td class="<?= ($log['is_available'] ?? 0) ? 'available' : 'occupied' ?>">
                                <?= ($log['is_available'] ?? 0) ? 'Available' : 'Occupied' ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </section>

        <!-- Pagination -->
        <div class="pagination">
            <?php if ($page > 1): ?>
                <a href="?page=1">&laquo; First</a>
                <a href="?page=<?= $page - 1 ?>">&lsaquo; Previous</a>
            <?php endif; ?>

            <?php if ($page < $totalPages): ?>
                <a href="?page=<?= $page + 1 ?>">Next &rsaquo;</a>
                <a href="?page=<?= $totalPages ?>">Last &raquo;</a>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
<?php include 'footer.php'; ?>

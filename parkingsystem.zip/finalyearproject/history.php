<?php
include 'header.php';
include 'sidebar.php';

// Database connection details
$host = "localhost";
$dbname = "parkingsystem";
$user = "root";
$password = "";

// Establish PDO connection
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $user, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Pagination logic for vehicle logs
$logsPerPage = 10;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$logOffset = ($page - 1) * $logsPerPage;

// Fetch vehicle log data with parking slot info (JOIN)
$logsQuery = $pdo->prepare("
    SELECT 
        b.id, 
        b.license_plate, 
        b.booking_date AS entry_time, 
        b.exit_time, 
        ps.slot_name, 
        ps.is_available 
    FROM 
        bookings b
    LEFT JOIN 
        parking_slots ps 
    ON 
        b.slot_id = ps.slot_id
    ORDER BY 
        b.booking_date DESC 
    LIMIT 
        :logOffset, :logsPerPage
");
$logsQuery->bindValue(':logOffset', $logOffset, PDO::PARAM_INT);
$logsQuery->bindValue(':logsPerPage', $logsPerPage, PDO::PARAM_INT);
$logsQuery->execute();
$logs = $logsQuery->fetchAll(PDO::FETCH_ASSOC);

// Count total number of logs
$totalLogsQuery = $pdo->query("SELECT COUNT(*) AS total FROM bookings");
$totalLogs = $totalLogsQuery->fetch(PDO::FETCH_ASSOC);
$totalLogsCount = $totalLogs['total'];

// Calculate total number of pages
$totalPages = ceil($totalLogsCount / $logsPerPage);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vehicle Parking History</title>
    <style>
      <style>
    body {
        font-family: 'Roboto', sans-serif;
        margin: 0;
        padding: 0;
        background-color: #f9f9f9;
    }

    .container {
        padding: 20px;
    }

    h1, h2 {
        color: #444;
        text-align: center;
    }

    .styled-table {
        width: 100%;
        border-collapse: collapse;
        margin: 25px 0;
        font-size: 0.9em;
        font-family: 'Roboto', sans-serif;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.15);
    }

    .styled-table thead tr {
        background-color: #000000; /* Black background for the header */
        color: #ffffff; /* White text for better readability */
        text-align: left;
    }

    .styled-table th, .styled-table td {
        padding: 12px 15px;
    }

    .styled-table tbody tr {
        border-bottom: 1px solid #dddddd;
    }

    .styled-table tbody tr:nth-of-type(even) {
        background-color: #f3f3f3;
    }

    .styled-table tbody tr:last-of-type {
        border-bottom: 2px solid #000000; /* Black bottom border */
    }

    .styled-table .available {
        color: green;
        font-weight: bold;
    }

    .styled-table .occupied {
        color: red;
        font-weight: bold;
    }

    .pagination {
        text-align: center;
        margin: 20px 0;
    }

    .pagination a {
        color: white;
        background-color: #007BFF;
        padding: 8px 16px;
        text-decoration: none;
        border-radius: 5px;
        margin: 0 5px;
    }

    .pagination a:hover {
        background-color: #0056b3;
    }
</style>

    </style>
</head>
<body>
<div style="margin-left:25%;padding:1px 16px;height:1000px;">
    <div class="container">
        <h1>Vehicle Parking History</h1>

        <!-- Vehicle Log Table with Parking Slot Info and Exit Time -->
        <section class="table-container">
            <h2>Parking History</h2>
            <table class="styled-table">
                <thead>
                    <tr>
                        <th>License Plate</th>
                        <th>Booking Date (Entry Time)</th>
                        <th>Exit Time</th>
                        <th>Parking Slot</th>
                        <th>Availability</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($logs as $log): ?>
                        <tr>
                            <td><?= htmlspecialchars($log['license_plate']) ?></td>
                            <td><?= htmlspecialchars($log['entry_time']) ?></td>
                            <td><?= htmlspecialchars($log['exit_time'] ?? 'N/A') ?></td>
                            <td><?= htmlspecialchars($log['slot_name'] ?? 'N/A') ?></td>
                            <td class="<?= ($log['is_available'] ?? 0) ? 'available' : 'occupied' ?>">
                                <?= ($log['is_available'] ?? 0) ? 'Available' : 'Occupied' ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </section>

        <!-- Pagination -->
        <div class="pagination">
            <?php if ($page > 1): ?>
                <a href="?page=1">&laquo; First</a>
                <a href="?page=<?= $page - 1 ?>">&lsaquo; Previous</a>
            <?php endif; ?>

            <?php if ($page < $totalPages): ?>
                <a href="?page=<?= $page + 1 ?>">Next &rsaquo;</a>
                <a href="?page=<?= $totalPages ?>">Last &raquo;</a>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>

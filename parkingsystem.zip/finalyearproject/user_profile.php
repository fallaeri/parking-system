<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: user_login.php");
    exit;
}

// Database connection
$host = "localhost";
$db = "parkingsystem";
$user = "root"; // Replace with your DB username
$pass = ""; // Replace with your DB password

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$message = "";
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $new_username = trim($_POST["username"]);
    $new_email = trim($_POST["email"]);
    $new_password = trim($_POST["password"]);
    $new_carplate = trim($_POST["carplate"]);

    // Update user information in the database
    $stmt = $conn->prepare("UPDATE users SET username = ?, email = ?, password = ?, license_plate = ? WHERE userid = ?");
    $hashed_password = password_hash($new_password, PASSWORD_DEFAULT); // Hash the password
    $stmt->bind_param("ssssi", $new_username, $new_email, $hashed_password, $new_carplate, $_SESSION['userid']);

    if ($stmt->execute()) {
        $message = "Profile updated successfully!";
        $_SESSION['username'] = $new_username; // Update session variable
        $_SESSION['email'] = $new_email; // Update session variable
        $_SESSION['license_plate'] = $new_carplate; // Update session variable
    } else {
        $message = "Error updating profile: " . $stmt->error;
    }

    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile</title>
    <style>
 body {
    display: flex;
    flex-direction: column; /* Stack children vertically */
    min-height: 100vh; /* Full height of the viewport */
    margin: 0;
    font-family: 'Arial', sans-serif;
    background: url('background.jpg') no-repeat center center fixed; /* Background image */
    background-size: cover; /* Cover the entire viewport */
    position: relative; /* Position for overlay */
}

header {
    background-color: rgba(51, 51, 51, 0.9); /* Dark Gray with transparency */
    color: white; /* White text */
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 15px 30px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); /* Shadow for depth */
    border-radius: 8px; /* Rounded corners */
    margin: 20px; /* Margin around the header */
}

.logo {
    font-size: 28px; /* Larger logo font */
    font-weight: bold;
    letter-spacing: 1px; /* Spacing between letters */
}

nav ul {
    list-style-type: none; /* Remove bullet points */
    margin: 0;
    padding: 0;
    display: flex;
}

nav ul li {
    margin-left: 30px; /* Space between links */
}

nav ul li a {
    color: white; /* White text for links */
    text-decoration: none; /* Remove underline */
    font-size: 18px;
    padding: 10px 15px; /* Padding around links */
    border-radius: 5px; /* Rounded corners for links */
    transition: background-color 0.3s, color 0.3s; /* Smooth transitions */
}

nav ul li a:hover {
    background-color: #FF9800; /* Amber background on hover */
    color: #333333; /* Dark gray text on hover */
}
footer {
            background-color: #333333; /* Same dark gray background */
            color: white; /* White text */
            text-align: center; /* Centered text */
            padding: 15px 0; /* Padding for footer */
            width: 100%; /* Full width */
            margin-top: auto; /* Push footer to the bottom */
            box-shadow: 0 -4px 8px rgba(0, 0, 0, 0.2); /* Shadow for depth */
        }

        footer p {
            margin: 0; /* Remove default margin */
            font-size: 16px; /* Font size for footer text */
        }
.content {
    flex: 1; /* Allow content to grow and fill space */
    padding: 20px; /* Padding for content */
    text-align: center; /* Centered text */
}

h2 {
    color: #ffffff; /* White text */
    margin-bottom: 20px; /* Space below heading */
    font-size: 2rem; /* Larger font size */
    text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.5); /* Subtle text shadow */
}

form {
    background-color: rgba(255, 255, 255, 0.95); /* Slightly more opaque white */
    padding: 40px; /* Increased padding for a more spacious feel */
    border-radius: 12px; /* Slightly larger border radius */
    box-shadow: 0 8px 30px rgba(0, 0, 0, 0.15); /* Deeper shadow for more depth */
    width: 400px; /* Fixed width for the form */
    margin: 0 auto; /* Center the form */
    transition: transform 0.3s; /* Smooth transition for scaling effect */
}

form:hover {
    transform: scale(1.02); /* Slightly scale up on hover */
}

input[type="text"],
input[type="email"],
input[type="password"] {
    width: calc(100% - 20px);
    padding: 12px; /* Increased padding for comfort */
    margin-bottom: 20px; /* Increased margin for better spacing */
    border: 1px solid #ddd; /* Softer light gray border */
    border-radius: 6px; /* Slightly larger border radius */
    font-size: 14px; /* Increased font size for better readability */
    transition: border-color 0.3s, box-shadow 0.3s; /* Smooth transition for border color and shadow */
}

input[type="text"]:focus,
input[type="email"]:focus,
input[type="password"]:focus {
    border-color: #333333; /* Highlight border on focus */
    box-shadow: 0 0 8px rgba(0, 123, 255, 0.5); /* Blue shadow on focus */
    outline: none; /* Remove default outline */
}

button {
    width: 100%;
    padding: 12px; /* Increased padding for comfort */
    background-color: #333333; /* Bright blue for the button */
    color: white;
    border: none;
    border-radius: 6px; /* Slightly larger border radius */
    font-size: 16px; /* Consistent font size */
    cursor: pointer;
    transition: background-color 0.3s, transform 0.2s; /* Smooth transitions */
}

button:hover {
    background-color: #0056b3; /* Darker blue on hover */
    transform: translateY(-3px); /* Slight lift effect on hover */
}
.message {
    margin: 20px 0;
    color: green; /* Success message color */
    font-weight: bold; /* Bold text */
}
    </style>
</head>
<body>
    <header>
        <div class="logo">VICTUS PARKING SYSTEM</div>
        <nav>
            <ul>
                <li><a href="user_dashboard.php">HOME</a></li>
                <li><a href="user_book.php">BOOK PARKING</a></li>
                <li><a href="user_booking_history.php">HISTORY</a></li>
                <li><a href="user_profile.php">EDIT PROFILE</a></li>
                <li><a href="logout.php">LOGOUT</a></li>
            </ul>
        </nav>
    </header>

    <div class="content">
        <h2>UPDATE YOUR PROFILE</h2>
        <?php if ($message): ?>
            <div class="message"><?php echo $message; ?></div>
        <?php endif; ?>
        <form method="POST" action="">
            <input type="text" name="username" placeholder="New Username" value="<?php echo htmlspecialchars($_SESSION['username'], ENT_QUOTES, 'UTF-8'); ?>" required>
            <input type="email" name="email" placeholder="New Email" value="<?php echo isset($_SESSION['email']) ? htmlspecialchars($_SESSION['email'], ENT_QUOTES, 'UTF-8') : ''; ?>" required>
            <input type="text" name="carplate" placeholder="Car Plate" value="<?php echo isset($_SESSION['license_plate']) ? htmlspecialchars($_SESSION['license_plate'], ENT_QUOTES, 'UTF-8') : ''; ?>" required>
            <input type="password" name="password" placeholder="New Password" required>
            <button type="submit">UPDATE</button>
        </form>
    </div>

    <footer>
        <p>&copy; 2025 Victus Parking System. All rights reserved.</p>
        <p><a href="terms.php" style="color: white;">Terms of Service</a> | <a href="privacy.php" style="color: white;">Privacy Policy</a></p>
    </footer>
</body>
</html>

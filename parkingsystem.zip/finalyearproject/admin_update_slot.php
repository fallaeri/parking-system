<!DOCTYPE html>
<html>
<head>
    <title>Admin - Edit Parking Slot</title>
    <style>
        body {
    margin: 0;
    font-family: 'Arial', sans-serif;
    background: url('background.jpg') no-repeat center center fixed;
    background-size: cover;
    color: white;
}

h1, h2 {
    text-align: center;
    margin: 20px 0;
    color: white; /* Consistent with the theme */
}

#parking-map {
    display: grid;
    grid-template-columns: repeat(8, 1fr); /* Adjust number of slots per row */
    gap: 10px;
    margin: 20px auto;
    max-width: 800px;
    padding: 20px;
    background-color: rgba(0, 0, 0, 0.8); /* Semi-transparent black for contrast */
    border-radius: 10px;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.5);
}

.slot {
    width: 60px;
    height: 60px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 14px;
    border: 1px solid rgba(255, 255, 255, 0.2); /* Subtle border */
    border-radius: 8px;
    cursor: pointer;
    transition: background-color 0.3s ease, transform 0.2s ease;
    color: white; /* Text color for consistency */
    background-color: rgba(255, 255, 255, 0.1); /* Default semi-transparent white */
}

.slot.available {
    background-color: rgba(68, 182, 68, 0.7); /* Bright green for available slots */
    color: black;
}

.slot.occupied {
    background-color: rgba(204, 79, 79, 0.7); /* Bright red for occupied slots */
    cursor: not-allowed;
}

.slot:hover {
    transform: scale(1.05); /* Slight zoom effect */
}

form {
    max-width: 800px;
    margin: 20px auto;
    padding: 20px;
    background-color: rgba(0, 0, 0, 0.8); /* Semi-transparent black */
    border-radius: 10px;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.5);
}

label {
    display: block;
    margin: 10px 0 5px;
    font-weight: bold;
    color: white; /* Amber for labels */
}

input[type="text"], input[type="number"] {
    width: calc(100% - 20px);
    padding: 10px;
    margin-bottom: 20px;
    border: 1px solid rgba(255, 255, 255, 0.2);
    border-radius: 5px;
    background-color: rgba(255, 255, 255, 0.1); /* Semi-transparent white */
    color: white;
    transition: border-color 0.3s ease, box-shadow 0.3s ease;
}

input[type="text"]:focus, input[type="number"]:focus {
    border-color: white; /* Amber highlight */
    box-shadow: 0 0 8px rgba(255, 193, 7, 0.5);
    outline: none;
}

input[type="checkbox"] {
    margin-left: 5px;
    transform: scale(1.2); /* Slightly larger checkboxes */
}
h2{
    color: black;
}
button {
    width: 100%;
    padding: 12px;
    background-color: #333333; /* Dark background for buttons */
    color: white; /* Amber text */
    border: none;
    border-radius: 5px;
    font-size: 16px;
    font-weight: bold;
    cursor: pointer;
    transition: background-color 0.3s ease, transform 0.2s ease;
}

button:hover {
    background-color: white; /* Amber background on hover */
    color: black; /* Black text on hover */
    transform: scale(1.03); /* Slight zoom effect */
}

        .main-content {
            padding-top: 80px; /* Adjust this value based on the header height */
            flex: 1; /* Allow the main content to grow */
        }
    </style>
</head>
<body>
<?php
include 'db.php'; // Include database connection
include 'header.php';

// Fetch all parking slots
$query = "SELECT slot_id, slot_name, is_available FROM parking_slots";
$slots = $pdo->query($query)->fetchAll(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $slot_id = $_POST['slot_id'];
    $slot_name = $_POST['slot_name'];
    $is_available = isset($_POST['is_available']) ? 1 : 0;

    $updateQuery = "UPDATE parking_slots
                    SET slot_name = :slot_name, 
                        is_available = :is_available
                    WHERE slot_id = :slot_id";

    $stmt = $pdo->prepare($updateQuery);
    $stmt->execute([
        'slot_name' => $slot_name,
        'is_available' => $is_available,
        'slot_id' => $slot_id
    ]);

    echo "Parking slot updated successfully!";
}
?>

<div style="main-content">
    <h1>Admin - Edit Parking Slot</h1>
    <h2>CLICK ON PARKING TO UPDATE</h2>
    <aside>

    <!-- Parking Map -->
    <div id="parking-map">
        <?php foreach ($slots as $slot): ?>
            <div class="slot <?php echo $slot['is_available'] ? 'available' : 'occupied'; ?>"
                 onclick="editSlot(<?php echo $slot['slot_id']; ?>)">
                <?php echo htmlspecialchars($slot['slot_name']); ?>
            </div>
        <?php endforeach; ?>
    </div>

    <!-- Form -->
    <?php if (isset($_GET['slot_id'])) {
        $slot_id = $_GET['slot_id'];
        $query = "SELECT * FROM parking_slots WHERE slot_id = :slot_id";
        $stmt = $pdo->prepare($query);
        $stmt->execute(['slot_id' => $slot_id]);
        $slot = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($slot): ?>
            <form method="POST">
                <input type="hidden" name="slot_id" value="<?php echo $slot['slot_id']; ?>">

                <label for="slot_name">Slot Name:</label>
                <input type="text" name="slot_name" id="slot_name" value="<?php echo htmlspecialchars($slot['slot_name']); ?>" required>

                <label for="is_available">Available:</label>
                <input type="checkbox" name="is_available" id="is_available" <?php echo $slot['is_available'] ? 'checked' : ''; ?>>

                <button type="submit">Update Slot</button>
            </form>
        <?php else: ?>
            <p>Slot not found.</p>
        <?php endif;
    } ?>
</div>

<script>
    function editSlot(slotId) {
        window.location.href = "admin_update_slot.php?slot_id=" + slotId;
    }

    function refreshParkingMap() {
        fetch("admin_update_slot.php")
            .then(response => response.text())
            .then(data => {
                const parser = new DOMParser();
                const doc = parser.parseFromString(data, 'text/html');
                const updatedMap = doc.querySelector('#parking-map');
                document.querySelector('#parking-map').innerHTML = updatedMap.innerHTML;
            })
            .catch(error => console.error('Error refreshing parking map:', error));
    }

    document.addEventListener('DOMContentLoaded', () => {
        const updateButton = document.querySelector('button[type="submit"]');
        if (updateButton) {
            updateButton.addEventListener('click', (e) => {
                e.preventDefault();
                const form = updateButton.closest('form');
                const formData = new FormData(form);

                fetch(form.action, {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.text())
                .then(() => {
                    alert('Parking slot updated successfully!');
                    refreshParkingMap();
                })
                .catch(error => console.error('Error updating parking slot:', error));
            });
        }
    });
</script>
</body>
</html>

<?php include 'footer.php'; ?>
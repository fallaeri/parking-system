<?php
include 'db.php'; // Include your database connection file

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['booking_id'])) {
    $bookingId = $_POST['booking_id'];

    // Prepare the delete statement
    $deleteQuery = $pdo->prepare("DELETE FROM bookings WHERE id = :id");
    $deleteQuery->bindParam(':id', $bookingId, PDO::PARAM_INT);

    if ($deleteQuery->execute()) {
        // Redirect back to the dashboard or bookings page with a success message
        header("Location: admin_manage_booking.php?message=Booking deleted successfully");
        exit;
    } else {
        // Handle error
        echo "Error deleting booking: " . $deleteQuery->errorInfo()[2];
    }
} else {
    // Redirect if accessed directly
    header("Location: admin_manage_booking.php");
    exit;
}
?>
<?php
// Start a session to manage user data.
session_start();

// Database connection.
$conn = new mysqli('localhost', 'root', '', 'parkingsystem');

// Check the connection.
if ($conn->connect_error) {
    die('Connection failed: ' . $conn->connect_error);
}

// Capture user input from the registration form.
$username = $_POST['username'];
$userid = $_POST['userid'];
$email = $_POST['email'];
$password = $_POST['password'];

// Validate inputs.
if (empty($username) || empty($userid) || empty($email) || empty($password)) {
    die('All fields are required.');
}

// Check if the User ID or email already exists in the database.
$sql_check = "SELECT * FROM users WHERE userid = ? OR email = ?";
$stmt_check = $conn->prepare($sql_check);

if (!$stmt_check) {
    die('SQL Error: ' . $conn->error);
}

$stmt_check->bind_param('ss', $userid, $email);
$stmt_check->execute();
$result_check = $stmt_check->get_result();

if ($result_check->num_rows > 0) {
    die('User ID or Email already exists.');
}

// Hash the password for secure storage.
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

// Insert the new user into the database.
$sql_insert = "INSERT INTO users (username, userid, email, password) VALUES (?, ?, ?, ?)";
$stmt_insert = $conn->prepare($sql_insert);

if (!$stmt_insert) {
    die('SQL Error: ' . $conn->error);
}

$stmt_insert->bind_param('ssss', $username, $userid, $email, $hashed_password);

if ($stmt_insert->execute()) {
    echo 'Registration successful! You can now <a href="user_login.php">login</a>.';
} else {
    echo 'Error: ' . $stmt_insert->error;
}

// Close the prepared statements and connection.
$stmt_check->close();
$stmt_insert->close();
$conn->close();
?>


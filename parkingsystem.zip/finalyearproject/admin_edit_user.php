<?php
// edit_user.php
include 'header.php';

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "parkingsystem"; 

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch user details
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $sql = "SELECT username, email FROM users WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
} else {
    die("User  ID not provided.");
}
?>

<div class="main-content">
    <h1>Edit User</h1>
    <form method="POST" action="update_user.php">
        <input type="hidden" name="id" value="<?php echo $id; ?>">
        <label for="username">Username:</label>
        <input type="text" name="username" value="<?php echo $user['username']; ?>" required>
        <br>
        <label for="email">Email:</label>
        <input type="email" name="email" value="<?php echo $user['email']; ?>" required>
        <br>
        <button type="submit">Update User</button>
    </form>
</div>

<?php
$conn->close();
?>
<?php include 'footer.php'; ?>
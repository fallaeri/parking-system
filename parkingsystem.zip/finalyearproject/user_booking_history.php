<?php
session_start(); // Start the session

// Database connection
$host = "localhost";
$db = "parkingsystem";
$user = "root"; // Replace with your DB username
$pass = ""; // Replace with your DB password

$conn = new mysqli($host, $user, $pass, $db);

$notFoundMessage = ""; 

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$results = [];
$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $license_plate = trim($_POST["license_plate"]);

    if (!empty($license_plate)) {
        $stmt = $conn->prepare("SELECT * FROM bookings WHERE license_plate = ? ORDER BY booking_date DESC");
        $stmt->bind_param("s", $license_plate);
        $stmt->execute();
        $result = $stmt->get_result();

        while ($row = $result->fetch_assoc()) {
            $results[] = $row;
        }

        $stmt->close();
    } else {
        $error = "Please enter a license plate number.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Purchase by License Plate</title>
    <style>
   body {
            display: flex;
            flex-direction: column; /* Stack children vertically */
            min-height: 100vh; /* Full height of the viewport */
            margin: 0;
            font-family: 'Arial', sans-serif;
            background: url('background.jpg') no-repeat center center fixed; /* Background image */
            background-size: cover; /* Cover the entire viewport */
            color: #333; /* Default text color */
        }

        header {
            background-color: #333333; /* Dark Gray */
            color: white; /* White text */
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 30px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); /* Shadow for depth */
            border-radius: 8px; /* Rounded corners */
            margin: 20px; /* Margin around the header */
        }

        .logo {
            font-size: 28px; /* Larger logo font */
            font-weight: bold;
            letter-spacing: 1px; /* Spacing between letters */
        }

        nav ul {
            list-style-type: none; /* Remove bullet points */
            margin: 0;
            padding: 0;
            display: flex;
        }

        nav ul li {
            margin-left: 30px; /* Space between links */
        }

        nav ul li a {
            color: white; /* White text for links */
            text-decoration: none; /* Remove underline */
            font-size: 18px;
            padding: 10px 15px; /* Padding around links */
            border-radius: 5px; /* Rounded corners for links */
            transition: background-color 0.3s, color 0.3s; /* Smooth transitions */
        }

        nav ul li a:hover {
            background-color: #FF9800; /* Amber background on hover */
            color: #333333; /* Dark gray text on hover */
        }

        h1 {
            text-align: center;
            font-size: 2rem;
            margin: 20px 0;
            color: #ffffff; /* White text for the heading */
        }

        form {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin: 20px auto;
            background-color: rgba(255, 255, 255, 0.9); /* Slightly transparent white */
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); /* Shadow for depth */
            width: 80%; /* Fixed width for the form */
        }

        label {
            font-size: 1rem;
            margin-bottom: 5px;
        }

        input[type="text"] {
            width: 100%; /* Full width */
            padding: 10px; /* Padding for input */
            margin-bottom: 15px; /* Space below input */
            border: 1px solid #ccc; /* Light border */
            border-radius: 5px; /* Rounded corners */
            transition: border-color 0.3s; /* Smooth transition for border color */
            text-align: center;
        }

        input[type="text"]:focus {
            border-color: #007bff; /* Highlight border on focus */
            outline: none; /* Remove default outline */
        }

        button {
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            background-color: #333333; /* Primary button color */
            color: white;
            cursor: pointer;
            font-weight: bold; /* Bold text for button */
            transition: background-color 0.3s, transform 0.2s; /* Smooth transitions */
        }

        button:hover {
            background-color: #0056b3; /* Darker shade on hover */
            transform: translateY(-2px); /* Slight lift effect on hover */
        }

        .error-message {
            color: red; /* Red color for error messages */
            text-align: center; /* Centered text */
        }

        table {
            width: 80%; /* Set table width */
            margin: 20px auto; /* Center the table */
            border-collapse: collapse; /* Remove space between cells */
            background-color: rgba(255, 255, 255, 0.9); /* Slightly transparent white */
            border-radius: 8px; /* Rounded corners */
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); /* Subtle shadow */
        }

        th, td {
            padding: 15px; /* Padding for cells */
            text-align: left; /* Left align text */
            text-align: center;
        }

        th {
            background-color: #333333; /* Dark Gray */
            color: white; /* White text */
        }

        tr:nth-child(even) {
            background-color: #f1f1f1; /* Light gray for even rows */
        }

        tr:hover {
            background-color: #e0e0e0; /* Light gray on hover */
        }

        footer {
            background-color: #333333; /* Same dark gray background */
            color: white; /* White text */
            text-align: center; /* Centered text */
            padding: 15px 0; /* Padding for footer */
            width: 100%; /* Full width */
            margin-top: auto; /* Push footer to the bottom */
            box-shadow: 0 -4px 8px rgba(0, 0, 0, 0.2); /* Shadow for depth */
        }

        footer p {
            margin: 0; /* Remove default margin */
            font-size: 16px; /* Font size for footer text */
        }
        .view-receipt-button {
    display: inline-block; /* Make it a block element */
    padding: 8px 12px; /* Padding for the button */
    background-color: #007bff; /* Button color */
    color: white; /* Text color */
    text-decoration: none; /* Remove underline */
    border-radius: 5px; /* Rounded corners */
    transition: background-color 0.3s; /* Smooth transition */
}

.view-receipt-button:hover {
    background-color: #0056b3; /* Darker shade on hover */
}
.no-results {
    background-color: #f8d7da; /* Light red background */
    color: #721c24; /* Dark red text */
    border: 1px solid #f5c6cb; /* Light red border */
    padding: 15px 20px; /* Padding inside the box */
    border-radius: 8px; /* Rounded corners */
    font-size: 16px; /* Slightly larger text */
    font-weight: bold; /* Bold text for emphasis */
    text-align: center; /* Center the text */
    margin: 20px auto; /* Add some spacing and center on the page */
    width: 80%; /* Adjust width to make it visually appealing */
    max-width: 600px; /* Set a maximum width */
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); /* Subtle shadow for depth */
    animation: fadeIn 0.5s ease; /* Smooth fade-in animation */
}
.session-license-plate {
    background-color: rgba(255, 255, 255, 0.9); /* Slightly transparent white background */
    border: 1px solid #007bff; /* Blue border */
    color: #333; /* Dark text color */
    padding: 15px; /* Padding around the text */
    border-radius: 8px; /* Rounded corners */
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); /* Subtle shadow for depth */
    margin: 20px auto; /* Center the box */
    width: 80%; /* Set a fixed width */
    max-width: 600px; /* Maximum width */
    text-align: center; /* Center the text */
    font-size: 1.2rem; /* Slightly larger font size */
    font-weight: bold; /* Bold text */
}
    </style>
</head>
<body>
<header>
        <div class="logo">VICTUS PARKING SYSTEM</div>
        <nav>
            <ul>
            <li><a href="user_dashboard.php">HOME</a></li>
                <li><a href="user_book.php">BOOK PARKING</a></li>
                <li><a href="user_booking_history.php">HISTORY</a></li>
                <li><a href="user_profile.php">EDIT PROFILE</a></li>
                <li><a href="logout.php">LOGOUT</a></li>
            </ul>
        </nav>
    </header>
    <h1>Your Purchase History</h1>

    <?php
// Debugging output
if (isset($_SESSION['license_plate'])) {
    echo "<div class='session-license-plate'>Session License Plate: " . htmlspecialchars($_SESSION['license_plate']) . "</div>";
} else {
    echo "<div class='session-license-plate'>No license plate found in session.</div>";
}
?>

    <form method="POST" action="">
        <label for="license_plate">License Plate:</label>
        <input type="text" id="license_plate" name="license_plate" 
               value="<?php echo isset($_SESSION['license_plate']) ? htmlspecialchars ($_SESSION['license_plate']) : ''; ?>" 
               required readonly>
        <button type="submit">Go</button>
    </form>
    <?php if ($error): ?>
        <p class="error-message"><?php echo htmlspecialchars($error); ?></p>
    <?php endif; ?>
    <?php if ($results): ?>
    <table>
        <tr>
            <th colspan="8">RESULT</th>
        </tr>
        <tr>
            <th>Booking Code</th>
            <th>License Plate</th>
            <th>Payment Method</th>
            <th>Duration</th>
            <th>Amount</th>
            <th>Status</th>
            <th>Booking Date</th>
            <th>Action</th>
        </tr>
        <?php foreach ($results as $row): ?>
    <tr>
        <td><?php echo htmlspecialchars($row["booking_code"]); ?></td>
        <td><?php echo htmlspecialchars($row["license_plate"]); ?></td>
        <td><?php echo htmlspecialchars($row["payment_method"]); ?></td>
        <td><?php echo htmlspecialchars($row["parking_duration"]); ?> hours</td>
        <td><?php echo htmlspecialchars($row["amount"]); ?></td>
        <td><?php echo htmlspecialchars($row["booking_status"]); ?></td>
        <td><?php echo htmlspecialchars($row["booking_date"]); ?></td>
        <td>
            <?php if (strcasecmp($row["booking_status"], "Pending") !== 0): ?>
                <a href="receipt.php?booking_code=<?php echo urlencode($row['booking_code']); ?>" class="view-receipt-button">View Receipt</a>
            <?php else: ?>
                N/A 
            <?php endif; ?>
        </td>
    </tr>
<?php endforeach; ?>
    </table>
<?php elseif ($_SERVER["REQUEST_METHOD"] === "POST" && empty($results)): ?>
    <p class="no-results">
    No results found for the license plate "<?php echo htmlspecialchars($license_plate); ?>"
</p>

<?php endif; ?>
<footer>
    <p>&copy; 2025 Victus Parking System. All rights reserved.</p>
    <p><a href="terms.php" style="color: white;">Terms of Service</a> | <a href="privacy.php" style="color: white;">Privacy Policy</a></p>
</footer>
</body>
</html>
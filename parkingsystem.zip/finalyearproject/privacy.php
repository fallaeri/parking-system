<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Privacy Policy - Victus Parking System</title>
    <link rel="stylesheet" href="styles.css"> <!-- Link to your CSS file -->
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
            color: #333;
        }
        header {
            background-color: #333;
            color: white;
            padding: 15px 30px;
            text-align: center;
        }
        .content {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        footer {
            text-align: center;
            padding: 15px 0;
            background-color: #333;
            color: white;
            position: relative;
            bottom: 0;
            width: 100%;
        }
    </style>
</head>
<body>
    <header>
        <h1>Victus Parking System</h1>
    </header>

    <div class="content">
        <h2>Privacy Policy</h2>
        <p>At Victus Parking System, we are committed to protecting your privacy. This Privacy Policy outlines how we collect, use, and safeguard your information when you use our services.</p>

        <h3>1. Information We Collect</h3>
        <p>We may collect the following types of information:</p>
        <ul>
            <li><strong>Personal Information:</strong> This includes your name, email address, phone number, and any other information you provide when creating an account or making a booking.</li>
            <li><strong>Payment Information:</strong> We collect payment details necessary to process your bookings. This information is securely processed and not stored on our servers.</li>
            <li><strong>Usage Data:</strong> We may collect information about how you use our services, including your IP address, browser type, and access times.</li>
        </ul>

        <h3>2. How We Use Your Information</h3>
        <p>Your information may be used in the following ways:</p>
        <ul>
            <li>To provide and maintain our services.</li>
            <li>To process your transactions and send you confirmations.</li>
            <li>To communicate with you, including responding to your inquiries and sending you updates.</li>
            <li>To improve our services and enhance user experience.</li>
            <li>To comply with legal obligations and protect our rights.</li>
        </ul>

        <h3>3. Data Security</h3>
        <p>We take the security of your personal information seriously. We implement a variety of security measures to maintain the safety of your personal information. However, no method of transmission over the Internet or method of electronic storage is 100% secure, and we cannot guarantee its absolute security.</p>

        <h3>4. Sharing Your Information</h3>
        <p>We do not sell, trade, or otherwise transfer your personal information to outside parties without your consent, except to provide our services or as required by law.</p>

        <h3>5. Your Rights</h3>
        <p>You have the right to:</p>
        <ul>
            <li>Access the personal information we hold about you.</li>
            <li>Request correction of any inaccurate information.</li>
            <li>Request deletion of your personal information.</li>
            <li>Withdraw consent for processing your personal information.</li>
        </ul>

        <h3>6. Changes to This Privacy Policy</h3>
        <p>We may update this Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page. You are advised to review this Privacy Policy periodically for any changes.</p>

        <h3>7. Contact Us</h3>
        <p>If you have any questions about this Privacy Policy, please contact us at <a href="mailto:support@victusparking.com">support@victusparking.com</a>.</p>
    </div>

    <footer>
        <p>&copy; 2024 Victus Parking System. All rights reserved.</p>
        <p><a href="user_dashboard.php" style="color: white;">Home</a> 
    </footer>
</body>
</html>
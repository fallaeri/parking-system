<?php 
// Database connection details
$host = "localhost";  // Database server
$dbname = "parkingsystem"; // Database name
$user = "root";       // Database username
$password = "";       // Database password

include 'header.php';

// Establish PDO connection
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $user, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Handle POST requests
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add_slot'])) {
        $slotName = trim($_POST['slot_name']);
        $isAvailable = isset($_POST['is_available']) ? 1 : 0;

        if (empty($slotName)) {
            $error = "Please enter a valid slot name.";
        } else {
            try {
                $insertSlotQuery = $pdo->prepare("INSERT INTO parking_slots (slot_name, is_available) VALUES (:slot_name, :is_available)");
                $insertSlotQuery->execute([
                    'slot_name' => $slotName, 
                    'is_available' => $isAvailable
                ]);
                $success = "Parking slot added successfully.";
            } catch (PDOException $e) {
                $error = "Error adding parking slot: " . $e->getMessage();
            }
        }
    }

    if (isset($_POST['delete_slot'])) {
        $slotId = (int)$_POST['slot_id'];

        if ($slotId <= 0) {
            $error = "Invalid slot ID.";
        } else {
            try {
                $deleteSlotQuery = $pdo->prepare("DELETE FROM parking_slots WHERE slot_id = :slot_id");
                $deleteSlotQuery->execute(['slot_id' => $slotId]);

                if ($deleteSlotQuery->rowCount() > 0) {
                    $success = "Parking slot deleted successfully.";
                } else {
                    $error = "Parking slot not found.";
                }
            } catch (PDOException $e) {
                $error = "Error deleting parking slot: " . $e->getMessage();
            }
        }
    }
}

// Fetch parking slots to display
$slotsQuery = $pdo->query("SELECT * FROM parking_slots ORDER BY slot_name");
$slotsData = $slotsQuery->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Manage Parking Slots</title>
    <style>
       body {
    font-family: 'Arial', sans-serif;
    margin: 0;
    padding: 0;
    color: white; /* Ensures white text consistency */
}

.container {
    max-width: 1000px;
    margin: 0 auto;
    padding: 20px;
    background-color: rgba(0, 0, 0, 0.8); /* Semi-transparent black for better contrast */
    border-radius: 10px; /* Rounded corners for modern look */
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.5); /* Subtle shadow to elevate the container */
}

h1, h2 {
    color: white;
    text-align: center; /* Centers the title */
    margin-bottom: 20px;
}

table {
    width: 80%;
    border-collapse: collapse;
    margin: 25px auto; /* Centers the table horizontally */
    font-size: 1em;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3);
    border-radius: 8px;
    overflow: hidden;
    background-color: black; /* Dark background for the table */
}


thead tr {
    background-color: #333333; /* Dark header row */
    color: white; /* Amber for header text */
    text-align: left;
}

th, td {
    padding: 15px 20px;
    border-bottom: 1px solid #444; /* Soft border between rows */
}

tbody tr {
    transition: background-color 0.3s;
}

tbody tr:nth-of-type(even) {
    background-color: rgba(255, 255, 255, 0.1); /* Light gray background for even rows */
}

tbody tr:hover {
    background-color: rgba(255, 255, 255, 0.2); /* Highlight row on hover */
}

tbody tr:last-of-type {
    border-bottom: 2px solid white; /* Amber border for last row */
}

.available {
    color: #00FF00; /* Bright green for available slots */
    font-weight: bold;
}

.occupied {
    color: #FF0000; /* Bright red for occupied slots */
    font-weight: bold;
}

.pagination {
    text-align: center;
    margin: 20px 0;
}

.pagination a {
    color: black;
    background-color: #333333; /* Dark background for pagination links */
    padding: 10px 20px;
    text-decoration: none;
    border-radius: 5px;
    margin: 0 5px;
    transition: background-color 0.3s;
}

.pagination a:hover {
    background-color: white; /* Lighter amber when hovering over pagination */
}
form {
    margin-bottom: 20px;
    padding: 20px;
    background-color: rgba(0, 0, 0, 0.8); /* Semi-transparent black for contrast */
    border-radius: 10px; /* Rounded corners */
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.5); /* Shadow for depth */
    width: 80%; /* Ensures the form fits the container */
    margin: 20px auto; /* Center the form on the page */
}
form {
    margin-bottom: 20px;
    padding: 20px;
    background-color: rgba(0, 0, 0, 0.8); /* Semi-transparent black for contrast */
    border-radius: 10px; /* Rounded corners */
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.5); /* Shadow for depth */
    width: 80%; /* Ensures the form fits the container */
    margin: 20px auto; /* Center the form on the page */
}


h2 {
    color: white; /* White text for the form header */
    text-align: center;
}

label {
    display: block;
    margin-bottom: 10px;
    color: white; /* White label text */
}

input[type="text"],
input[type="checkbox"] {
    width: calc(100% - 22px); /* Ensures input spans full width */
    padding: 10px;
    margin-bottom: 20px;
    border: 1px solid #ccc;
    border-radius: 4px;
    transition: border-color 0.3s;
    background-color: #fff; /* White background for the inputs */
}

input[type="text"]:focus {
    border-color: #007BFF; /* Highlight border when focused */
    outline: none;
}

input[type="checkbox"] {
    width: auto;
    margin-right: 10px;
}

input[type="submit"] {
    padding: 10px 15px;
    background-color: #007BFF;
    color: white;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    transition: background-color 0.3s;
    width: 100%;
    font-size: 16px;
}

input[type="submit"]:hover {
    background-color: #0056b3; /* Darker blue when hovered */
}
/* General Message Styling */
.message {
    width: 80%;
    margin: 20px auto;
    padding: 15px;
    text-align: center;
    font-size: 16px;
    font-weight: bold;
    border-radius: 5px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
}

/* Success Message Styling */
.message.success {
    background-color: #d4edda; /* Light green background */
    color: #155724; /* Dark green text */
    border: 1px solid #c3e6cb; /* Green border */
}

/* Error Message Styling */
.message.error {
    background-color: #f8d7da; /* Light red background */
    color: #721c24; /* Dark red text */
    border: 1px solid #f5c6cb; /* Red border */
}



    </style>
</head>
<body>

    <h1>Admin - Manage Parking Slots</h1>

    <!-- Display success or error messages -->
    <?php if (isset($success)): ?>
        <div class="message success"><?= htmlspecialchars($success) ?></div>
    <?php elseif (isset($error)): ?>
        <div class="message error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <!-- Form to add a new parking slot -->
    <form method="POST">
        <h2>Add New Slot</h2>
        <label for="slot_name">Slot Name:</label>
        <input type="text" id="slot_name" name="slot_name" required>
        <br>
        <label for="is_available">Available:</label>
        <input type="checkbox" id="is_available" name="is_available">
        <br>
        <input type="submit" name="add_slot" value="Add Slot">
    </form>

    <!-- Display existing parking slots -->
    <table>
        <thead>
            <tr>
                <th>Slot ID</th>
                <th>Slot Name</th>
                <th>Availability</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($slotsData as $slot): ?>
                <tr>
                    <td><?= htmlspecialchars($slot['slot_id']) ?></td>
                    <td><?= htmlspecialchars($slot['slot_name']) ?></td>
                    <td><?= $slot['is_available'] ? 'Available' : 'Occupied' ?></td>
                    <td>
                        <!-- Corrected Delete Button -->
                        <form method="POST" style="display:inline;">
                            <input type="hidden" name="slot_id" value="<?= htmlspecialchars($slot['slot_id']) ?>">
                            <input type="submit" name="delete_slot" value="Delete" onclick="return confirm('Are you sure you want to delete this slot?');">
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>
</html>
<?php include 'footer.php'; ?>
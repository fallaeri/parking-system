<?php
date_default_timezone_set('Asia/Kuala_Lumpur');
// Database connection details
$host = "localhost";  // Database server
$dbname = "parkingsystem"; // Database name
$user = "root";       // Database username
$password = "";       // Database password

// Establish PDO connection
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $user, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Get the current time
$currentTime = date('Y-m-d H:i:s');

// Update all bookings where the exit_time is less than the current time
$updateQuery = $pdo->prepare("
    UPDATE bookings b
    LEFT JOIN parking_slots ps ON b.slot_id = ps.slot_id
    SET ps.is_available = 1, b.booking_status = 'completed' 
    WHERE b.exit_time IS NOT NULL 
    AND b.exit_time <= :current_time 
    AND ps.is_available = 0
");

$updateQuery->bindValue(':current_time', $currentTime, PDO::PARAM_STR);
$updateQuery->execute();

echo "Slots updated successfully!";
?>

<style>
    body, ul {
        margin: 0;
        padding: 0;
        font-family: Arial, sans-serif;
    }
    ul {
        width: 20%;
        font-size: 16px;
        background-color: black;
        color: white;
        position: fixed;
        height: 100%;
        overflow: auto;
        list-style: none;
    }
    li a {
        display: block;
        color: white;
        padding: 10px 15px;
        text-decoration: none;
    }
    li a:hover {
        background-color: #e6b800;
        color: white;
    }
</style>
<ul>
   <li><a href="admin_dashboard.php">Your Dashboard</a></li>
		<li><a href="admin_manage_booking.php">Manage Booking</a></li>
		<li><a href="admin_check_history.php">Parking History</a></li>
		<li><a href="admin_update_slot.php">Update Parking</a></li>
		<li><a href="admin_manage_user.php">Manage User</a></li>
		<li><a href="admin_add_slot.php">Add Parking Slot</a></li>
        <li><a href="gate_qrscan.php">Gate</a></li>
		<li><a href="logout.php">Logout</a></li>
	</ul>
<footer>
    <p>&copy; <?php echo date('Y'); ?> Victus Parking System. All rights reserved.</p>
</footer>
<style>
    footer {
        background-color: black; 
        color: white; 
        text-align: center; 
        padding: 15px 0; 
        width: 100%; 
        position: fixed;
        bottom: 0;
    }

    footer p {
        margin: 0; 
        font-size: 16px; 
    }
</style>

<?php
include 'db.php';

try {
    // Establish PDO connection
    $pdo = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Fetch parking slots data (status, position) for the parking lot table
$slotsQuery = $pdo->query("SELECT slot_id, slot_name, is_available FROM parking_slots");
$slotsData = $slotsQuery->fetchAll(PDO::FETCH_ASSOC);

// Fetch bookings for pagination
$logsPerPage = 10;  // Show 10 bookings per page
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $logsPerPage;

$logsQuery = $pdo->prepare("SELECT bookings.id, bookings.booking_code, bookings.license_plate, bookings.payment_method, 
                            bookings.parking_duration, bookings.amount, bookings.booking_status, bookings.booking_date, 
                            bookings.exit_time, parking_slots.slot_name 
                            FROM bookings
                            JOIN parking_slots ON bookings.slot_id = parking_slots.slot_id
                            ORDER BY bookings.booking_date DESC 
                            LIMIT :offset, :limit");
$logsQuery->bindParam(':offset', $offset, PDO::PARAM_INT);
$logsQuery->bindParam(':limit', $logsPerPage, PDO::PARAM_INT);
$logsQuery->execute();
$logs = $logsQuery->fetchAll(PDO::FETCH_ASSOC);

// Fetch total number of bookings for pagination
$totalLogsQuery = $pdo->query("SELECT COUNT(*) AS total FROM bookings");
$totalLogs = $totalLogsQuery->fetch(PDO::FETCH_ASSOC);
$totalPages = ceil($totalLogs['total'] / $logsPerPage);

// Handle report generation
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['generate_report'])) {
    $startDate = $_POST['start_date'];
    $endDate = $_POST['end_date'];

    // Validate date range
    if ($startDate > $endDate) {
        echo "<script>alert('Start date cannot be later than the end date');</script>";
    } else {
        $reportQuery = $pdo->prepare("SELECT bookings.id, bookings.booking_code, bookings.license_plate, bookings.payment_method, 
                                      bookings.parking_duration, bookings.amount, bookings.booking_status, bookings.booking_date, 
                                      bookings.exit_time, parking_slots.slot_name
                                      FROM bookings
                                      JOIN parking_slots ON bookings.slot_id = parking_slots.slot_id
                                      WHERE booking_date BETWEEN :start_date AND :end_date");
        $reportQuery->execute(['start_date' => $startDate, 'end_date' => $endDate]);
        $reportData = $reportQuery->fetchAll(PDO::FETCH_ASSOC);

        if ($reportData) {
            // Generate CSV report
            header('Content-Type: text/csv');
            header('Content-Disposition: attachment; filename="report.csv"');
            $output = fopen('php://output', 'w');
            fputcsv($output, ['ID', 'Booking Code', 'License Plate', 'Payment Method', 'Parking Duration', 'Amount', 
                              'Booking Status', 'Booking Date', 'Exit Time', 'Slot Name']);
            foreach ($reportData as $row) {
                fputcsv($output, $row);
            }
            fclose($output);
            exit;
        } else {
            echo "<script>alert('No data found for the selected date range');</script>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Parking Lot Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f9f9f9;
        }
        h1, h2 {
            color: #333;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
            background-color: #fff;
        }
        table th, table td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: center;
        }
        table th {
            background-color: #f4f4f4;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
        }
        .form-group input {
            width: 100%;
            padding: 8px;
            box-sizing: border-box;
        }
        .alert {
            padding: 10px;
            margin-bottom: 20px;
            color: #fff;
            background-color: #4CAF50;
        }
    </style>
</head>
<body>

<h1>Parking Lot Dashboard</h1>

<?php if (isset($_GET['message'])): ?>
    <div class="alert"><?= htmlspecialchars($_GET['message']) ?></div>
<?php endif; ?>

<!-- Booking Logs -->
<section>
    <h2>Bookings</h2>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Booking Code</th>
                <th>License Plate</th>
                <th>Payment Method</th>
                <th>Parking Duration (hrs)</th>
                <th>Amount</th>
                <th>Status</th>
                <th>Booking Date</th>
                <th>Exit Time</th>
                <th>Slot Name</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($logs as $log): ?>
                <tr>
                    <td><?= htmlspecialchars($log['id']) ?></td>
                    <td><?= htmlspecialchars($log['booking_code']) ?></td>
                    <td><?= htmlspecialchars($log['license_plate']) ?></td>
                    <td><?= htmlspecialchars($log['payment_method']) ?></td>
                    <td><?= htmlspecialchars($log['parking_duration']) ?></td>
                    <td><?= htmlspecialchars($log['amount']) ?></td>
                    <td><?= htmlspecialchars($log['booking_status']) ?></td>
                    <td><?= htmlspecialchars($log['booking_date']) ?></td>
                    <td><?= htmlspecialchars($log['exit_time'] ?? 'N/A') ?></td>
                    <td><?= htmlspecialchars($log['slot_name']) ?></td>
                    <td>
                        <form method="POST" action="delete_booking.php" style="display:inline;">
                            <input type="hidden" name="booking_id" value="<?= htmlspecialchars($log['id']) ?>">
                            <button type="submit" onclick="return confirm('Are you sure you want to delete this booking?');">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</section>

<!-- Pagination -->
<div>
    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
        <a href="?page=<?= $i ?>" style="margin: 0 5px;"><?= $i ?></a>
    <?php endfor; ?>
</div>

<!-- Report Generation -->
<section>
    <h2>Generate Report</h2>
    <form method="POST">
        <div class="form-group">
            <label for="start_date">Start Date:</label>
            <input type="date" name="start_date" required>
        </div>
        <div class="form-group">
            <label for="end_date">End Date:</label>
            <input type="date" name="end_date" required>
        </div>
        <button type="submit" name="generate_report">Generate Report</button>
    </form>
</section>

</body>
</html>
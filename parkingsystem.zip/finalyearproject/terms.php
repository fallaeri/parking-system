<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Terms of Service - Victus Parking System</title>
    <link rel="stylesheet" href="styles.css"> <!-- Link to your CSS file -->
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
            color: #333;
        }
        header {
            background-color: #333;
            color: white;
            padding: 15px 30px;
            text-align: center;
        }
        .content {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        footer {
            text-align: center;
            padding: 15px 0;
            background-color: #333;
            color: white;
            position: relative;
            bottom: 0;
            width: 100%;
        }
    </style>
</head>
<body>
    <header>
        <h1>Victus Parking System</h1>
    </header>

    <div class="content">
        <h2>Terms of Service</h2>
        <p>Welcome to the Victus Parking System. By using our services, you agree to the following terms and conditions:</p>

        <h3>1. Acceptance of Terms</h3>
        <p>By accessing and using our services, you accept and agree to be bound by these terms. If you do not agree to these terms, please do not use our services.</p>

        <h3>2. User Responsibilities</h3>
        <p>Users are responsible for maintaining the confidentiality of their account information and for all activities that occur under their account. You agree to notify us immediately of any unauthorized use of your account.</p>

        <h3>3. Booking and Payment</h3>
        <p>All bookings made through our system are subject to availability. Payment must be made at the time of booking. We reserve the right to change our pricing at any time.</p>

        <h3>4. Cancellations and Refunds</h3>
        <p>Cancellations must be made at least 24 hours in advance to receive a full refund. Refunds will be processed within 7-10 business days.</p>

        <h3>5. Limitation of Liability</h3>
        <p>Victus Parking System is not liable for any damages or losses resulting from the use of our services. We do not guarantee the availability of parking spaces.</p>

        <h3>6. Changes to Terms</h3>
        <p>We reserve the right to modify these terms at any time. Changes will be effective immediately upon posting on our website. Your continued use of our services after changes are made constitutes your acceptance of the new terms.</p>

        <h3>7. Governing Law</h3>
        <p>These terms are governed by the laws of [Your Country/State]. Any disputes arising from these terms will be resolved in the courts of [Your Jurisdiction].</p>

        <h3>8. Contact Us</h3>
        <p>If you have any questions about these terms, please contact us at <a href="mailto:support@victusparking.com">support@victusparking.com</a>.</p>
    </div>

    <footer>
        <p>&copy; 2024 Victus Parking System. All rights reserved.</p>
        <p><a href="user_dashboard.php" style="color: white;">Home</a> 
    </footer>
</body>
</html>
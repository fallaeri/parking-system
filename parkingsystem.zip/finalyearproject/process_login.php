<?php
session_start();

// Redirect if already logged in
if (isset($_SESSION['username'])) {
    header("Location: user_dashboard.php");
    exit;
}

// Database connection
try {
    $conn = new mysqli("localhost", "root", "", "parkingsystem");
    if ($conn->connect_error) {
        throw new Exception("Connection failed: " . $conn->connect_error);
    }
} catch (Exception $e) {
    die("Error: " . $e->getMessage());
}

// Check if the form inputs are set
if (isset($_POST['username']) && isset($_POST['password'])) {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    // Validate inputs
    if (empty($username) || empty($password)) {
        echo "<script>alert('Username or Password cannot be empty'); window.location.href='user_login.php';</script>";
        exit;
    }

    // Prepare and execute the query securely
    $sql = "SELECT * FROM users WHERE username = ?";
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        die("Error preparing statement: " . $conn->error);
    }

    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if a matching user exists
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();

        // Verify password
        if (password_verify($password, $row['password'])) {
            // Regenerate session ID for security
            session_regenerate_id(true);

            // Store user details in the session
            $_SESSION['username'] = $row['username'];
            $_SESSION['email'] = $row['email'];
            $_SESSION['userid'] = $row['userid'];
            $_SESSION['license_plate'] = $row['license_plate'] ?? 'Not Set. Please go to Edit Profile';

            // Redirect to dashboard
            header("Location: user_dashboard.php");
            exit;
        } else {
            echo "<script>alert('Invalid Username or Password'); window.location.href='user_login.php';</script>";
        }
    } else {
        echo "<script>alert('Invalid Username or Password'); window.location.href='user_login.php';</script>";
    }

    $stmt->close();
} else {
    echo "<script>alert('Please enter both Username and Password'); window.location.href='user_login.php';</script>";
}

$conn->close();
?>

<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: user_login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Victus Parking System</title>
    <style>
        body {
            display: flex;
            flex-direction: column; /* Stack children vertically */
            min-height: 100vh; /* Full height of the viewport */
            margin: 0;
            font-family: 'Arial', sans-serif;
            background: url('background.jpg') no-repeat center center fixed; /* Background image */
            background-size: cover; /* Cover the entire viewport */
            position: relative; /* Position for overlay */
        }

        header {
            background-color: #333333; /* Dark Gray */
            color: white; /* White text */
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 30px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); /* Shadow for depth */
            border-radius: 8px; /* Rounded corners */
            margin: 20px; /* Margin around the header */
        }

        .logo {
            font-size: 28px; /* Larger logo font */
            font-weight: bold;
            letter-spacing: 1px; /* Spacing between letters */
        }

        nav ul {
            list-style-type: none; /* Remove bullet points */
            margin: 0;
            padding: 0;
            display: flex;
        }

        nav ul li {
            margin-left: 30px; /* Space between links */
        }

        nav ul li a {
            color: white; /* White text for links */
            text-decoration: none; /* Remove underline */
            font-size: 18px;
            padding: 10px 15px; /* Padding around links */
            border-radius: 5px; /* Rounded corners for links */
            transition: background-color 0.3s, color 0.3s; /* Smooth transitions */
        }

        nav ul li a:hover {
            background-color: #FF9800; /* Amber background on hover */
            color: #333333; /* Dark gray text on hover */
        }

        footer {
            background-color: #333333; /* Same dark gray background */
            color: white; /* White text */
            text-align: center; /* Centered text */
            padding: 15px 0; /* Padding for footer */
            width: 100%; /* Full width */
            margin-top: auto; /* Push footer to the bottom */
            box-shadow: 0 -4px 8px rgba(0, 0, 0, 0.2); /* Shadow for depth */
        }

        footer p {
            margin: 0; /* Remove default margin */
            font-size: 16px; /* Font size for footer text */
        }

        .content {
            flex: 1; /* Allow content to grow and fill space */
            padding: 20px; /* Padding for content */
            text-align: center; /* Centered text */
			margin-left: -30%;
        }

        /* Additional styles for the user info table */
        .user-info {
            width: 80%; /* Set a width for the table */
            margin: 20px auto; /* Center the table */
            border-collapse: collapse; /* Remove space between cells */
            background-color: #ffffff; /* White background for the table */
            border-radius: 8px; /* Rounded corners */
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); /* Subtle shadow */
        }

        .user-info th {
            background-color: #333333; /* Dark Gray */
            color: white; /* White text */
            padding: 15px; /* Padding for header cells */
            font-size: 24px; /* Font size for header */
            border-top-left-radius: 8px; /* Rounded corners */
            border-top-right-radius: 8px; /* Rounded corners */
        }

        .user-info td {
            padding: 15px; /* Padding for data cells */
            font-size: 18px; /* Font size for data */
            border-bottom: 1px solid #dddddd; /* Light gray border */
        }

        .user-info tr:hover {
            background-color: #f1f1f1; /* Light gray background on hover */
        }

        .user-info td b {
            color: #333333; /* Dark gray for labels */
        }

        .welcome-message {
            font-size: 32px; /* Larger font for welcome message */
            margin: 20px 0; /* Margin for spacing */
            color:rgb(255, 255, 255); /* Dark gray text */
        }
    </style>
</head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<body>
    <header>
        <div class="logo">VICTUS PARKING SYSTEM</div>
        <nav>
            <ul>
            <li><a href="user_dashboard.php">HOME</a></li>
                <li><a href="user_book.php">BOOK PARKING</a></li>
                <li><a href="user_booking_history.php">HISTORY</a></li>
                <li><a href="user_profile.php">EDIT PROFILE</a></li>
                <li><a href="logout.php">LOGOUT</a></li>
            </ul>
        </nav>
    </header>

    <div class="content">
        <div style="margin-left:25%;padding:1px 16px;height:1000px;">
            <p class="welcome-message">WELCOME TO VICTUS PARKING !</p>
            <table class="user-info">
                <tr>
                    <th colspan="2">User  Information</th>
                </tr>
                <tr>
                    <td><b>Name:</b> <?php echo $_SESSION['username']; ?></td>
                </tr>
                <tr>
                    <td><b>User ID:</b> <?php echo $_SESSION['userid']; ?></td>
                </tr>
                <tr>
                    <td><b>Email:</b> <?php echo $_SESSION['email']; ?></td>
                </tr>
                <tr>
                <td><b>Car Plate:</b> <?php echo ($_SESSION['license_plate']) ? $_SESSION['license_plate'] : 'Not Set'; ?></td>
                </tr>
            </table>
        </div>
    </div>

    <footer>
    <p>&copy; 2025 Victus Parking System. All rights reserved.</p>
    <p><a href="terms.php" style="color: white;">Terms of Service</a> | <a href="privacy.php" style="color: white;">Privacy Policy</a></p>
</footer>
</body>
</html>
<?php

// Set the PHP default timezone to Asia/Kuala_Lumpur (UTC +08:00)
date_default_timezone_set('Asia/Kuala_Lumpur');

include 'db.php';

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch available parking slots
$slots_result = $conn->query("SELECT slot_id, slot_name, position_x, position_y, is_available FROM parking_slots");
$slots = [];
if ($slots_result->num_rows > 0) {
    while ($row = $slots_result->fetch_assoc()) {
        $slots[] = $row;
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Retrieve form data
    $license_plate = $_POST['license_plate'];
    $hours = $_POST['hours'];  // Number of hours parked
    $slot_id = $_POST['parking_slot'];
    $rate_per_hour = 5.00;  // Rate per hour of parking

    // Calculate the total amount for the parking
    $amount = $hours * $rate_per_hour;  // Total parking cost

    // Generate a unique booking code
    $booking_code = strtoupper(substr(md5(uniqid($license_plate, true)), 0, 8));
    $booking_status = 'pending'; // Initial status

    // Calculate the exit time by adding the parking duration to the current time
    $current_time = new DateTime();
    $exit_time = $current_time->add(new DateInterval('PT' . $hours . 'H')); // Add hours to current time
    $exit_time_formatted = $exit_time->format('Y-m-d H:i:s'); // Format as MySQL datetime

    // Insert the booking record into the database
    $stmt = $conn->prepare("INSERT INTO bookings (booking_code, license_plate, parking_duration, amount, booking_status, slot_id, exit_time) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssidsis", $booking_code, $license_plate, $hours, $amount, $booking_status, $slot_id, $exit_time_formatted);

    if ($stmt->execute()) {
        // Update the parking slot status to 'occupied'
        $slot_stmt = $conn->prepare("UPDATE parking_slots SET is_available = 0 WHERE slot_id = ?");
        $slot_stmt->bind_param("i", $slot_id);
        $slot_stmt->execute();

        // Redirect the user to the payment page
        header("Location: payment.php?booking_code=$booking_code&amount=$amount&license_plate=$license_plate");
        exit;
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Parking Booking System</title>
    <style>
        #parking-map {
            width: 800px;
            height: 1100px;
            border: 1px solid #000;
            position: relative;
        }
        .slot {
            width: 50px;
            height: 50px;
            position: absolute;
            text-align: center;
            line-height: 50px;
            border: 1px solid #000;
            cursor: pointer;
        }
        .available {
            background-color: #90ee90; /* Light green */
        }
        .occupied {
            background-color: #ffcccb; /* Light red */
            cursor: not-allowed;
        }
    </style>
    <script>
        function selectSlot(slotId) {
            document.getElementById('parking_slot').value = slotId;
        }
    </script>
</head>
<body>
    <h1>Parking Booking System</h1>
    <form action="booking.php" method="post">
        <label for="license_plate">License Plate:</label>
        <input type="text" name="license_plate" id="license_plate" placeholder="Enter License Plate" required>
        <br><br>

        <label for="hours">Parking Duration (in hours):</label>
        <input type="number" name="hours" id="hours" placeholder="Enter hours parked" min="1" required>
        <br><br>

        <label for="parking_slot">Selected Parking Slot:</label>
        <input type="text" name="parking_slot" id="parking_slot" readonly required>
        <br><br>

        <div id="parking-map">
            <?php foreach ($slots as $slot): ?>
                <div class="slot <?php echo $slot['is_available'] ? 'available' : 'occupied'; ?>"
                     style="top: <?php echo $slot['position_y']; ?>px; left: <?php echo $slot['position_x']; ?>px;"
                     onclick="selectSlot(<?php echo $slot['slot_id']; ?>)"
                     <?php echo !$slot['is_available'] ? 'title="Occupied"' : ''; ?>>
                    <?php echo $slot['slot_name']; ?>
                </div>
            <?php endforeach; ?>
        </div>
        <br>

        <button type="submit">Proceed to Booking</button>
    </form>

    <hr>

    <!-- Display the calculated exit time (optional, only if you want to show it on the page before submission) -->
    <?php if ($_SERVER['REQUEST_METHOD'] == 'POST'): ?>
        <h3>Summary:</h3>
        <p>License Plate: <?php echo htmlspecialchars($license_plate); ?></p>
        <p>Parking Duration: <?php echo htmlspecialchars($hours); ?> hours</p>
        <p>Total Amount: RM <?php echo number_format($amount, 2); ?></p>
        <p>Exit Time: <?php echo $exit_time_formatted; ?></p>
    <?php endif; ?>
</body>
</html>
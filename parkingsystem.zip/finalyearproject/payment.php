<?php
include 'db.php';

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get booking details from the URL
if (isset($_GET['booking_code']) && isset($_GET['amount']) && isset($_GET['license_plate'])) {
    $booking_code = $_GET['booking_code'];
    $amount = $_GET['amount'];
    $license_plate = $_GET['license_plate'];
    
    // Process the payment
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $payment_method = $_POST['payment_method'];

        // Simulate payment processing (e.g., confirm payment and update booking status)
        $payment_status = 'completed';

        // Update booking status to 'confirmed' in the database
        $stmt = $conn->prepare("UPDATE bookings SET booking_status=?, payment_method=? WHERE booking_code=?");
        $stmt->bind_param("sss", $payment_status, $payment_method, $booking_code);
        
        if ($stmt->execute()) {
            // Redirect to receipt.php with the booking_code
            header("Location: receipt.php?booking_code=$booking_code");
            exit; // Ensure no further execution after redirection
        } else {
            echo "Error: " . $stmt->error;
        }

        // Close the statement
        $stmt->close();
    }
} else {
    echo "Booking details missing!";
    exit;
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment System</title>
    <style>
        body {
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    margin: 0;
    font-family: 'Arial', sans-serif;
    background: url('background.jpg') no-repeat center center fixed; /* Background image */
    background-size: cover; /* Cover the entire viewport */
    position: relative; /* Position for overlay */
}

.container {
    text-align: center;
    background-color: rgba(255, 255, 255, 0.9); /* Slightly transparent white */
    padding: 30px;
    border: 1px solid #e0e0e0; /* Lighter border */
    border-radius: 15px; /* More rounded corners */
    box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2); /* Deeper shadow for depth */
    width: 350px; /* Slightly wider */
    backdrop-filter: blur(10px); /* Blur effect for background */
}

h1 {
    font-size: 2rem; /* Larger font size */
    margin-bottom: 15px;
    color: #333; /* Darker text color */
}

p {
    font-size: 1.1rem; /* Slightly larger font size */
    margin-bottom: 25px;
    color: #666; /* Softer text color */
}

form {
    display: flex;
    flex-direction: column;
    align-items: center;
}

label {
    font-size: 1rem;
    color: #333; /* Darker text color */
    margin-bottom: 5px; /* Space between label and input */
}

select, button {
    margin-bottom: 15px; /* Increased space */
    font-size: 1rem;
    width: 100%; /* Full width for inputs */
    padding: 10px; /* Padding for inputs */
    border: 1px solid #ccc; /* Border for inputs */
    border-radius: 5px; /* Rounded corners for inputs */
    transition: border-color 0.3s; /* Smooth transition for border color */
}

select:focus, button:focus {
    border-color: #007bff; /* Highlight border on focus */
    outline: none; /* Remove default outline */
}

button {
    background-color: #007bff; /* Primary button color */
    color: white;
    cursor: pointer;
    font-weight: bold; /* Bold text for button */
    transition: background-color 0.3s, transform 0.2s; /* Smooth transitions */
}

button:hover {
    background-color: #0056b3; /* Darker shade on hover */
    transform: translateY(-2px); /* Slight lift effect on hover */
}

button:active {
    transform: translateY(0); /* Reset lift effect on click */
}
    </style>
</head>
<body>
    <div class="container">
        <h1>Payment for Booking: <?php echo htmlspecialchars($booking_code); ?></h1>
        <p>Your total amount to pay: RM<?php echo number_format($amount, 2); ?></p>

        <form action="payment.php?booking_code=<?php echo htmlspecialchars($booking_code); ?>&amount=<?php echo htmlspecialchars($amount); ?>&license_plate=<?php echo htmlspecialchars($license_plate); ?>" method="post">
            <label for="payment_method">Choose Payment Method:</label>
            <select name="payment_method" id="payment_method" required>
                <option value="ewallet">E-Wallet</option>
                <option value="online_banking">Online Banking</option>
            </select>
            <br>
            <button type="submit">Proceed</button>
        </form>
    </div>
</body>
</html>

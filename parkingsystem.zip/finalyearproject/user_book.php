<?php

session_start();
include 'db.php'; // Include your database connection

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch available parking slots
$slots_result = $conn->query("SELECT slot_id, slot_name, position_x, position_y, is_available FROM parking_slots");
$slots = [];
if ($slots_result->num_rows > 0) {
    while ($row = $slots_result->fetch_assoc()) {
        $slots[] = $row;
    }
}

// Booking submission logic
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $license_plate = $_POST['license_plate'];
    $hours = $_POST['hours'];
    $slot_id = $_POST['parking_slot'];
    $rate_per_hour = 5.00;

    $amount = $hours * $rate_per_hour;
    $booking_code = strtoupper(substr(md5(uniqid($license_plate, true)), 0, 8));
    $booking_status = 'pending';

    $stmt = $conn->prepare("INSERT INTO bookings (booking_code, license_plate, parking_duration, amount, booking_status, slot_id) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssidsi", $booking_code, $license_plate, $hours, $amount, $booking_status, $slot_id);

    if ($stmt->execute()) {
        $slot_stmt = $conn->prepare("UPDATE parking_slots SET is_available = 0 WHERE slot_id = ?");
        $slot_stmt->bind_param("i", $slot_id);
        $slot_stmt->execute();

        header("Location: payment.php?booking_code=$booking_code&amount=$amount&license_plate=$license_plate");
        exit;
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>User Book</title>
    <style>
  body {
            display: flex;
            flex-direction: column; /* Stack children vertically */
            min-height: 100vh; /* Full height of the viewport */
            margin: 0;
            font-family: 'Arial', sans-serif;
            background: url('background.jpg') no-repeat center center fixed; /* Background image */
            background-size: cover; /* Cover the entire viewport */
            position: relative; /* Position for overlay */
        }

        header {
            background-color: #333333; /* Dark Gray */
            color: white; /* White text */
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 30px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); /* Shadow for depth */
            border-radius: 8px; /* Rounded corners */
            margin: 20px; /* Margin around the header */
        }

        .logo {
            font-size: 28px; /* Larger logo font */
            font-weight: bold;
            letter-spacing: 1px; /* Spacing between letters */
        }

        nav ul {
            list-style-type: none; /* Remove bullet points */
            margin: 0;
            padding: 0;
            display: flex;
        }

        nav ul li {
            margin-left: 30px; /* Space between links */
        }

        nav ul li a {
            color: white; /* White text for links */
            text-decoration: none; /* Remove underline */
            font-size: 18px;
            padding: 10px 15px; /* Padding around links */
            border-radius: 5px; /* Rounded corners for links */
            transition: background-color 0.3s, color 0.3s; /* Smooth transitions */
        }

        nav ul li a:hover {
            background-color: #FF9800; /* Amber background on hover */
            color: #333333; /* Dark gray text on hover */
        }

        footer {
            background-color: #333333; /* Same dark gray background */
            color: white; /* White text */
            text-align: center; /* Centered text */
            padding: 15px 0; /* Padding for footer */
            width: 100%; /* Full width */
            margin-top: auto; /* Push footer to the bottom */
            box-shadow: 0 -4px 8px rgba(0, 0, 0, 0.2); /* Shadow for depth */
        }

        footer p {
            margin: 0; /* Remove default margin */
            font-size: 16px; /* Font size for footer text */
        }

        .basic_box {
    border: 1px solid #ccc; /* Light gray border */
    border-radius: 15px;
    margin: 20px auto;
    width: 90%;
    max-width: 800px;
    padding: 20px;
    background: rgba(255, 255, 255, 0.95); /* Slightly transparent white */
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2); /* Deeper shadow for depth */
    transition: transform 0.3s; /* Smooth transition for scaling */
}

.basic_box:hover {
    transform: scale(1.02); /* Slightly scale up on hover */
}

h2 {
    text-align: center;
    color: #333333;
    margin-bottom: 20px; /* Space below heading */
    font-size: 1.8rem; /* Larger font size */
    text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.5); /* Subtle text shadow */
}

label {
    display: block;
    margin: 10px 0 5px;
    font-weight: bold;
    color:rgb(4, 4, 4); /* White text */
}

input[type="text"],
input[type="number"] {
    width: calc(100% - 20px);
    padding: 10px;
    margin-bottom: 20px;
    border: 1px solid #ccc; /* Light gray border */
    border-radius: 5px;
    transition: border-color 0.3s, box-shadow 0.3s; /* Smooth transition for border color and shadow */
}

input[type="text"]:focus,
input[type="number"]:focus {
    border-color: #007bff; /* Highlight border on focus */
    box-shadow: 0 0 5px rgba(0, 123, 255, 0.5); /* Blue shadow on focus */
    outline: none; /* Remove default outline */
}

#parking-map {
    display: grid;
    grid-template-columns: repeat(8, 1fr); /* 8 slots per row */
    gap: 10px; /* Space between slots */
    margin: 20px 0;
    padding: 10px;
    border: 2px solid #ccc; /* Light gray border */
    border-radius: 5px;
    background: rgba(255, 255, 255, 0.9); /* Slightly transparent white */
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1); /* Subtle shadow */
}

.slot {
    width: 60px; /* Slot width */
    height: 60px; /* Slot height */
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 14px;
    border: 1px solid #ccc; /* Light gray border */
    cursor: pointer;
    border-radius: 4px;
    transition: background-color 0.3s, transform 0.2s; /* Smooth transitions */
}

.slot.available {
    background-color: #90ee90; /* Light green for available slots */
    box-shadow: 0 2px 5px rgba(0, 255, 0, 0.3); /* Green shadow */
}

.slot.available:hover {
    background-color: #76c76a; /* Darker green on hover */
    transform: translateY(-2px); /* Lift effect on hover */
}

.slot.occupied {
    background-color: #ffcccb; /* Light red for occupied slots */
    cursor: not-allowed;
    box-shadow: none; /* No shadow for occupied slots */
}

button {
    width: 100%;
    padding: 10px;
    background-color: #333333; /* Dark gray */
    color: white;
    border: none;
    border-radius: 5px;
    font-size: 16px;
    cursor: pointer;
    transition: background-color 0.3s, transform 0.2s; /* Smooth transitions */
}

button:hover {
    background-color: #0056b3; /* Darker blue on hover */
    transform: translateY(-2px); /* Slight lift effect on hover */
    box-shadow: 0 4px 10px rgba(0, 86, 179, 0.5); /* Shadow on hover */
}
    </style>
    <script>
        function selectSlot(slotId) {
            if (document.getElementById('slot-' + slotId).classList.contains('occupied')) {
                alert('This slot is already occupied.');
                return;
            }
            document.getElementById('parking_slot').value = slotId;
            alert('You have selected slot: ' + slotId);
        }
    </script>
</head>
<body>
<header>
        <div class="logo">VICTUS PARKING SYSTEM</div>
        <nav>
            <ul>
            <li><a href="user_dashboard.php">HOME</a></li>
                <li><a href="user_book.php">BOOK PARKING</a></li>
                <li><a href="user_booking_history.php">HISTORY</a></li>
                <li><a href="user_profile.php">EDIT PROFILE</a></li>
                <li><a href="logout.php">LOGOUT</a></li>
            </ul>
        </nav>
    </header>
    <body>
    <div class="basic_box">
    <h2>BOOK YOUR PARKING</h2>
    <form action="booking.php" method="post">
        <label for="license_plate">LICENSE PLATE:</label>
        <input type="text" name="license_plate" id="license_plate" 
               value="<?php echo isset($_SESSION['license_plate']) ? $_SESSION['license_plate'] : ''; ?>" 
               placeholder="GO TO EDIT PROFILE TO ADD YOUR LICENSE PLATE" required readonly>

        <label for="hours">PARKING DURATION (in hours):</label>
        <input type="number" name="hours" id="hours" placeholder="ENTER PARKING DURATION" min="1" required>

        <label for="parking_slot">SELECT YOUR PARKING SLOT :</label>
        <input type="text" name="parking_slot" id="parking_slot" readonly required>

        <div id="parking-map">
            <?php foreach ($slots as $slot): ?>
                <div class="slot <?php echo $slot['is_available'] ? 'available' : 'occupied'; ?>"
                     id="slot-<?php echo $slot['slot_id']; ?>"
                     onclick="selectSlot(<?php echo $slot['slot_id']; ?>)">
                    <?php echo $slot['slot_name']; ?>
                </div>
            <?php endforeach; ?>
        </div>
        <button type="submit">Proceed to Booking</button>
    </form>
</div>
    <footer>
    <p>&copy; 2025 Victus Parking System. All rights reserved.</p>
    <p><a href="terms.php" style="color: white;">Terms of Service</a> | <a href="privacy.php" style="color: white;">Privacy Policy</a></p>
</footer>
</body>
</html>
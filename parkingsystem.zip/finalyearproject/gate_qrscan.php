<?php
$con = new mysqli("localhost", "root", "", "parkingsystem");

// Check connection
if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
}

if (isset($_POST['text'])) {
    $text = $con->real_escape_string($_POST['text']); // Escape special characters for security

    // Check if the QR code already exists in the database
    $query = $con->query("SELECT * FROM `qrscanner` WHERE `booking_detail` = '$text'");
    $row = $query->fetch_assoc();

    if ($row) {
        // QR code already exists, check its status
        if (is_null($row['entry_time'])) {
            // First scan: Set entry time
            $update = $con->query("UPDATE `qrscanner` SET `entry_time` = NOW() WHERE `booking_detail` = '$text'");
            if ($update) {
                echo "<script>alert('Entry time recorded successfully.')</script>";
            } else {
                echo "<script>alert('Failed to record entry time: " . $con->error . "')</script>";
            }
        } elseif (is_null($row['exit_time'])) {
            // Second scan: Set exit time
            $update = $con->query("UPDATE `qrscanner` SET `exit_time` = NOW() WHERE `booking_detail` = '$text'");
            if ($update) {
                echo "<script>alert('Exit time recorded successfully.')</script>";
            } else {
                echo "<script>alert('Failed to record exit time: " . $con->error . "')</script>";
            }
        } else {
            // Third scan or more: Invalid
            echo "<script>alert('Invalid scan: This QR code has already been used.')</script>";
        }
    } else {
        // QR code does not exist, insert it with only the entry time
        $insert = $con->query("INSERT INTO `qrscanner` (`booking_detail`, `entry_time`) VALUES ('$text', NOW())");
        if ($insert) {
            echo "<script>alert('Entry time recorded successfully.')</script>";
        } else {
            echo "<script>alert('Failed to record entry time: " . $con->error . "')</script>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>QR Scanner</title>
    
    <!-- CDN for webcam -->
    <script type="text/javascript" src="https://rawgit.com/schmich/instascan-builds/master/instascan.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
    <style>
       body {
    font-family: 'Arial', sans-serif;
    margin: 0;
    padding: 0;
    color: #f8f9fa;
    background: url('background1.jpg') no-repeat center center fixed;
    background-size: cover;
    position: relative;
}

.container {
    margin: 50px auto;
    background: linear-gradient(135deg, rgba(0, 0, 0, 0.7), rgba(40, 40, 40, 0.7)); /* Gradient for depth */
    border-radius: 15px;
    box-shadow: 0 6px 30px rgba(0, 0, 0, 0.3); /* Deeper shadow */
    padding: 40px;
    width: 85%;
    max-width: 1200px;
    min-height: 800px;
    color: #ffffff;
    text-align: center; /* Center-align text */
}

h2 {
    margin-bottom: 20px;
    font-size: 2rem;
    font-weight: bold;
    color: #ffffff;
    text-shadow: 0 3px 6px rgba(0, 0, 0, 0.3); /* Subtle text shadow for readability */
}

h3 {
    margin-bottom: 30px;
    font-size: 1.5rem;
    font-weight: bold;
    color: #1e90ff; /* Bright blue for emphasis */
}

.video-container {
    display: flex;
    justify-content: center;
    align-items: center;
    margin-bottom: 30px;
}

video {
    border: 3px solid #007bff;
    border-radius: 15px;
    width: 60%;
    max-width: 800px;
    box-shadow: 0 4px 15px rgba(0, 123, 255, 0.5); /* Add a shadow around the video */
}

table {
    width: 100%;
    margin-top: 30px;
    border-collapse: collapse;
    color: #000000; /* Black font color */
    background-color: #ffffff; /* White background */
    text-align: left;
}

thead th {
    background: #343a40;
    color: #ffffff;
    font-weight: bold;
    padding: 12px;
    text-transform: uppercase;
}

tbody tr:nth-child(odd) {
    background: rgba(255, 255, 255, 0.1); /* Subtle alternating row color */
}

tbody tr:nth-child(even) {
    background: rgba(0, 0, 0, 0.4);
}

td {
    padding: 10px;
    border: 1px solid #dee2e6;
}

.btn-danger {
    background-color: #e74c3c;
    border: none;
    padding: 8px 15px;
    border-radius: 5px;
    color: white;
    font-weight: bold;
    text-transform: uppercase;
    cursor: pointer;
    transition: background-color 0.3s ease, transform 0.2s ease;
}

.btn-danger:hover {
    background-color: #c0392b;
    transform: scale(1.05); /* Slightly enlarge on hover */
}

.table-bordered {
    border: 1px solid rgba(255, 255, 255, 0.2); /* Subtle table border */
}

.table-bordered th, .table-bordered td {
    border: 1px solid rgba(255, 255, 255, 0.2); /* Subtle cell borders */
}

    </style>
</head>

<body>
    <div class="container">
        <h2 class="text-center">QR Code Scanner</h2>
        <h3 class="text-center">PLACE YOUR QR INSIDE THE FRAME</h3>
        <div class="video-container">
            <video src="" id="MyCameraOpen"></video>
        </div>
        <form action="" method="POST">
            <input type="text" readonly hidden name="text" id="text" />
        </form>

        <table class="table table-bordered text-center">
            <thead class="thead-dark">
                <tr>
                    <th>PN</th>
                    <th>Parking Details</th>
                    <th>Entry Time</th>
                    <th>Exit Time</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $data = $con->query("SELECT * FROM qrscanner");
                $i = 0;
                while ($d = $data->fetch_assoc()) { ?>
                <tr>
                    <td><?php echo ++$i; ?></td>
                    <td><?php echo htmlspecialchars($d['booking_detail']); ?></td>
                    <td><?php echo htmlspecialchars($d['entry_time']); ?></td>
                    <td><?php echo htmlspecialchars($d['exit_time']); ?></td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>

    <script>
        // Start camera section
        var video = document.getElementById('MyCameraOpen');
        var text = document.getElementById('text');

        var scanner = new Instascan.Scanner({
            video: video,
        });

        // Start text section
        Instascan.Camera.getCameras()
            .then(function(Our_Camera) {
                if (Our_Camera.length > 0) {
                    scanner.start(Our_Camera[0]);
                } else {
                    alert('Camera Failed');
                }
            })
            .catch(function(error) {
                console.log('There is a problem, please try again');
            });

        scanner.addListener('scan', function(input_value) {
            text.value = input_value;
            document.forms[0].submit();
        });
    </script>
</body>
<a href="admin_dashboard.php" style="color: white;">HOME</a>
</html>

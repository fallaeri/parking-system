<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: admin_login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Victus Parking System</title>
    <style>
        body {
            display: flex;
            flex-direction: column; /* Stack children vertically */
            min-height: 100vh; /* Full height of the viewport */
            margin: 0;
            font-family: 'Arial', sans-serif;
            background: url('background1.jpg') no-repeat center center fixed; /* Background image */
            background-size: cover; /* Cover the entire viewport */
            position: relative; /* Position for overlay */
        }

        header {
            position: fixed; /* Fix the header at the top */
            top: 0; /* Align to the top */
            left: 0; /* Align to the left */
            right: 0; /* Align to the right */
            background-color: black; /* Dark Gray */
            color: white; /* White text */
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 30px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); /* Shadow for depth */
            z-index: 1000; /* Ensure the header is above other content */
        }

        .logo {
            font-size: 25px; /* Larger logo font */
            font-weight: bold;
            letter-spacing: 1px; /* Spacing between letters */
        }

        nav ul {
            list-style-type: none; /* Remove bullet points */
            margin: 0;
            padding: 0;
            display: flex;
        }

        nav ul li {
            margin-left: 30px; /* Space between links */
        }

        nav ul li a {
            color: white; /* White text for links */
            text-decoration: none; /* Remove underline */
            font-size: 13px;
            padding: 10px 15px; /* Padding around links */
            border-radius: 5px; /* Rounded corners for links */
            transition: background-color 0.3s, color 0.3s; /* Smooth transitions */
        }

        nav ul li a:hover {
            background-color: #FF9800; /* Amber background on hover */
            color: black; /* Dark gray text on hover */
        }

        /* Add padding to the main content to avoid overlap with the fixed header */
        .main-content {
            padding-top: 80px; /* Adjust this value based on the header height */
            flex: 1; /* Allow the main content to grow */
        }
    </style>
</head>
<body>
    <header>
        <div class="logo">VICTUS PARKING SYSTEM</div>
        <nav>
            <ul>
                <li><a href="admin_dashboard.php">Your Dashboard</a></li>
                <li><a href="admin_manage_booking.php">Manage Booking</a></li>
                <li><a href="admin_check_history.php">Parking History</a></li>
                <li><a href="admin_update_slot.php">Update Parking</a></li>
                <li><a href="admin_manage_user.php">Manage User</a></li>
                <li><a href="admin_add_slot.php">Add Parking Slot</a></li>
                <li><a href="gate_qrscan.php">Gate</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </nav>
    </header>
</body>
</html>
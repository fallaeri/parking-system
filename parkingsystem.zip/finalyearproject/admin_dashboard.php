<!DOCTYPE html>
<html lang="en">
<head>
    <title>Admin Dashboard</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f2f2f2;
            display: flex;
            flex-direction: column; /* Stack children vertically */
            min-height: 100vh; /* Full height of the viewport */
        }

        /* Header styles */
        header {
            position: fixed; /* Fix the header at the top */
            top: 0; /* Align to the top */
            left: 0; /* Align to the left */
            right: 0; /* Align to the right */
            background-color: #333333; /* Dark Gray */
            color: white; /* White text */
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 30px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); /* Shadow for depth */
            z-index: 1000; /* Ensure the header is above other content */
        }

        .logo {
            font-size: 28px; /* Larger logo font */
            font-weight: bold;
            letter-spacing: 1px; /* Spacing between letters */
        }

        nav ul {
            list-style-type: none; /* Remove bullet points */
            margin: 0;
            padding: 0;
            display: flex;
        }

        nav ul li {
            margin-left: 30px; /* Space between links */
        }

        nav ul li a {
            color: white; /* White text for links */
            text-decoration: none; /* Remove underline */
            font-size: 18px;
            padding: 10px 15px; /* Padding around links */
            border-radius: 5px; /* Rounded corners for links */
            transition: background-color 0.3s, color 0.3s; /* Smooth transitions */
        }

        nav ul li a:hover {
            background-color: #FF9800; /* Amber background on hover */
            color: #333333; /* Dark gray text on hover */
        }

        /* Main content area */
        .main-content {
            flex: 1; /* Allow the main content to grow */
            padding-top: 80px; /* Adjust this value based on the header height */
            display: flex; /* Use flexbox for centering */
            justify-content: center; /* Center horizontally */
            align-items: center; /* Center vertically */
        }

        .basic_box {
            border: none; /* Remove the border for a cleaner look */
            border-radius: 20px; /* Slightly larger border radius for a softer appearance */
            width: 600px; /* Fixed width */
            padding: 40px; /* Reduced padding for a more compact design */
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2); /* Softer shadow for depth */
            background: linear-gradient(135deg, #ffffff, #f9f9f9); /* Subtle gradient background */
            color: #333; /* Darker text color for better contrast */
            transition: transform 0.3s, box-shadow 0.3s; /* Smooth transition for hover effect */
        }

        .basic_box:hover {
            transform: translateY(-5px); /* Lift effect on hover */
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.3); /* Enhanced shadow on hover */
        }

        .decor {
            font-family: Arial, sans-serif;
            text-align: center; /* Center text for a more balanced look */
        }

        .basic_box p {
            margin: 10px 0; /* Add margin between paragraphs for spacing */
        }
    </style>
</head>
<body>

<?php include 'header.php'; ?>

<div class="main-content">
    <div class="basic_box decor">    
        <p style="font-size: 38px;"><b>Welcome to Admin Dashboard!</b></p>
        <p><b>Name:</b> <?php echo $_SESSION['username']; ?></p>
        <p><b>Admin ID:</b> <?php echo $_SESSION['adminid']; ?></p>
        <p><b>Email:</b> <?php echo $_SESSION['email']; ?></p>
    </div>
</div>

</body>
<?php include 'footer.php'; ?>
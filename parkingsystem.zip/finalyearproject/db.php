<?php
$servername = "localhost"; // Your database server (usually localhost)
$username = "root"; // Your database username (change this if needed)
$password = ""; // Your database password (usually blank for XAMPP)
$dbname = "parkingsystem"; // The name of your database

try {
    // Create a PDO instance for database connection
    $pdo = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    // Set the PDO error mode to exception
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    // If the connection fails, display an error message
    die("Connection failed: " . $e->getMessage());
}
?>
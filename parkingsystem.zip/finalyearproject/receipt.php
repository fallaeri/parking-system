<?php
include 'db.php';

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve booking_code from query string
if (isset($_GET['booking_code'])) {
    $booking_code = $_GET['booking_code'];

    // Fetch booking details from the database
    $stmt = $conn->prepare("SELECT booking_code, license_plate, payment_method, parking_duration, amount, booking_status FROM bookings WHERE booking_code = ?");
    $stmt->bind_param("s", $booking_code);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $booking = $result->fetch_assoc();
    } else {
        echo "<p>Invalid booking code. Please check your receipt details.</p>";
        exit;
    }

    // Close statement
    $stmt->close();
} else {
    echo "<p>No booking code provided. Please check your receipt details.</p>";
    exit;
}

// Close connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Receipt</title>
    <style>
        /* Your existing styles */
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            font-family: Arial, sans-serif;
            background: url('background.jpg') no-repeat center center fixed; /* Background image */
            background-size: cover; /* Cover the entire viewport */
            position: relative; /* Position for overlay */
        }
        .container {
            text-align: center;
            background-color: #ffffff;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            width: 400px;
        }
        h1 {
            font-size: 1.5rem;
            margin-bottom: 10px;
        }
        h2 {
            font-size: 1.2rem;
            margin-bottom: 20px;
            color: #007bff;
        }
        h3 {
            font-size: 1.2rem;
            margin-bottom: 20px;
            color:rgb(255, 0, 0);
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        table th, table td {
            text-align: left;
            padding: 10px;
            border-bottom: 1px solid #ddd;
        }
        table th {
            background-color: #f4f4f4;
            font-weight: bold;
        }
        .total td {
            font-weight: bold;
            color: #333;
        }
        .center {
            margin-top: 10px;
        }
        .center p {
            font-size: 0.9rem;
            color: #555;
        }
        #qrcode {
    display: flex; /* Use flexbox for centering */
    justify-content: center; /* Center horizontally */
    align-items: center; /* Center vertically */
    margin-top: 20px; /* Space above the QR code */
    width: 100%; /* Full width of the parent container */
    height: 250px; /* Set a height to center vertically */
}
    </style>
    <script src="qrcode.min.js"></script> 
</head>
<body>
    <div class="container">
        <h1>Parking Receipt</h1>
        <h2>Booking Code: <?= htmlspecialchars($booking['booking_code']) ?></h2>
        <table>
            <tr>
                <th>License Plate:</th>
                <td><?= htmlspecialchars($booking['license_plate']) ?></td>
            </tr>
            <tr>
                <th >Payment Method:</th>
                <td><?= htmlspecialchars($booking['payment_method']) ?></td>
            </tr>
            <tr>
                <th>Parking Duration:</th>
                <td><?= htmlspecialchars($booking['parking_duration']) ?> hours</td>
            </tr>
            <tr>
                <th>Status:</th>
                <td><?= htmlspecialchars(ucfirst($booking['booking_status'])) ?></td>
            </tr>
            <tr class="total">
                <th>Total Amount:</th>
                <td>RM<?= number_format($booking['amount'], 2) ?></td>
            </tr>
        </table>
        <h2>SHOW THIS QR AT THE CAMERA </h2>
        <h3>THIS QR USE WHEN ENTRY AND EXIT</h3>
        <div id="qrcode" style="margin-top: 20px;"></div>
        <script>
            const qrData = {
                booking_code: "<?= htmlspecialchars($booking['booking_code']) ?>",
                license_plate: "<?= htmlspecialchars($booking['license_plate']) ?>",
                amount: "RM<?= number_format($booking['amount'], 2) ?>",
                duration: "<?= htmlspecialchars($booking['parking_duration']) ?> hours"
            };
            

            const qrcode = new QRCode(document.getElementById("qrcode"), {
                text: JSON.stringify(qrData),
                width: 250,
                height: 250,
            });
        </script>
        <div class="center">
            <p>Thank you for using our parking service! <a href="user_dashboard.php">Return to Home</a></p>
        </div>
    </div>
</body>
</html>